export type PropertyType = 'apartment' | 'villa' | 'shop' | 'land' | 'office' | 'commercial';
export type ListingType = 'sale' | 'rent';
export type PropertyStatus = 'pending' | 'approved' | 'rejected' | 'hidden';
export type Currency = 'EGP' | 'USD' | 'SAR';
export type UserRole = 'user' | 'admin';

export interface Profile {
  id: string;
  email: string;
  display_name: string | null;
  phone: string | null;
  whatsapp: string | null;
  role: UserRole;
  suspended: boolean;
  created_at: string;
  updated_at: string;
}

export interface Property {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  price: number;
  currency: Currency;
  property_type: PropertyType;
  listing_type: ListingType;
  governorate: string;
  city: string;
  area_name: string | null;
  address: string | null;
  area_sqm: number | null;
  bedrooms: number | null;
  bathrooms: number | null;
  contact_phone: string | null;
  contact_whatsapp: string | null;
  status: PropertyStatus;
  featured: boolean;
  main_image_url: string | null;
  created_at: string;
  updated_at: string;
  property_images?: PropertyImage[];
}

export interface PropertyImage {
  id: string;
  property_id: string;
  image_url: string;
  sort_order: number;
  created_at: string;
}

export type InquiryStatus = 'new' | 'contacted' | 'closed';

export interface Inquiry {
  id: string;
  property_id: string;
  name: string;
  phone: string | null;
  email: string | null;
  message: string | null;
  status: InquiryStatus;
  created_at: string;
}
