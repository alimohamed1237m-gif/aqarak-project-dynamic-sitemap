import { Link } from 'react-router-dom';
import { MapPin, BedDouble, Bath, Maximize } from 'lucide-react';
import type { Property } from '@/types';
import { formatPrice, PROPERTY_TYPE_LABELS, LISTING_TYPE_LABELS } from '@/lib/constants';

interface PropertyCardProps {
  property: Property;
}

export default function PropertyCard({ property }: PropertyCardProps) {
  const imageUrl = property.main_image_url || property.property_images?.[0]?.image_url;

  return (
    <Link to={`/property/${property.id}`} className="card group block">
      {/* Image */}
      <div className="relative h-52 overflow-hidden bg-navy-100">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={property.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-navy-400">
            <Maximize className="w-12 h-12" />
          </div>
        )}
        {/* Badges */}
        <div className="absolute top-3 right-3 flex flex-col gap-1.5">
          <span className={`badge ${property.listing_type === 'sale' ? 'bg-gold-500 text-navy-900' : 'bg-accent-500 text-white'}`}>
            {LISTING_TYPE_LABELS[property.listing_type]}
          </span>
          {property.featured && (
            <span className="badge bg-navy-900 text-gold-400">مميز</span>
          )}
        </div>
        {/* Type */}
        <div className="absolute top-3 left-3">
          <span className="badge bg-white/90 text-navy-800">
            {PROPERTY_TYPE_LABELS[property.property_type]}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        <h3 className="font-bold text-navy-900 line-clamp-2 group-hover:text-gold-600 transition-colors leading-snug">
          {property.title}
        </h3>

        {/* Location */}
        <div className="flex items-center gap-1.5 text-sm text-navy-500">
          <MapPin className="w-4 h-4 text-gold-500 shrink-0" />
          <span className="truncate">{property.governorate} - {property.city}</span>
        </div>

        {/* Specs */}
        <div className="flex items-center gap-4 text-sm text-navy-600">
          {property.bedrooms != null && (
            <span className="flex items-center gap-1">
              <BedDouble className="w-4 h-4 text-navy-400" />
              {property.bedrooms}
            </span>
          )}
          {property.bathrooms != null && (
            <span className="flex items-center gap-1">
              <Bath className="w-4 h-4 text-navy-400" />
              {property.bathrooms}
            </span>
          )}
          {property.area_sqm != null && (
            <span className="flex items-center gap-1">
              <Maximize className="w-4 h-4 text-navy-400" />
              {property.area_sqm} م²
            </span>
          )}
        </div>

        {/* Price */}
        <div className="flex items-center justify-between pt-2 border-t border-navy-100">
          <span className="text-lg font-bold text-gold-600">
            {formatPrice(property.price, property.currency)}
          </span>
          {property.listing_type === 'rent' && (
            <span className="text-xs text-navy-500">/ شهرياً</span>
          )}
        </div>
      </div>
    </Link>
  );
}
