import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { Menu, X, LogOut, User, LayoutDashboard, PlusCircle, Search, List, MapPin, Facebook, Instagram } from 'lucide-react';
import { BUSINESS_ADDRESS, FACEBOOK_URL, INSTAGRAM_URL } from '@/lib/constants';
import { useAuth } from '@/context/AuthContext';

export default function Navbar() {
  const { session, profile, isAdmin, signOut } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
    setMobileOpen(false);
  };

  const navLinks = [
    { to: '/', label: 'الرئيسية' },
    { to: '/search', label: 'البحث' },
    { to: '/about', label: 'من نحن' },
    { to: '/contact', label: 'اتصل بنا' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-navy-100 shadow-sm">
      <nav className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center shrink-0" aria-label="عقارك مباشر">
            <img
              src="/images/1791649155527.jpg"
              alt="عقارك مباشر - Aqarak Mobasher"
              className="h-14 w-14 rounded-xl object-cover shadow-sm sm:h-16 sm:w-16"
            />
          </Link>

          {/* Desktop nav */}
          <div className="hidden lg:flex items-center gap-6">
            <span className="flex items-center gap-1.5 text-sm text-navy-500" title="موقعنا">
              <MapPin className="h-4 w-4 text-gold-500" />
              {BUSINESS_ADDRESS}
            </span>
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="text-navy-700 hover:text-gold-600 font-semibold transition-colors duration-200"
              >
                {link.label}
              </Link>
            ))}
            <div className="flex items-center gap-2 border-r border-navy-100 pr-4">
              <a href={FACEBOOK_URL} target="_blank" rel="noopener noreferrer" aria-label="فيسبوك" className="text-navy-500 hover:text-gold-600 transition-colors">
                <Facebook className="h-4 w-4" />
              </a>
              <a href={INSTAGRAM_URL} target="_blank" rel="noopener noreferrer" aria-label="انستجرام" className="text-navy-500 hover:text-gold-600 transition-colors">
                <Instagram className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Desktop auth */}
          <div className="hidden lg:flex items-center gap-3">
            <Link
              to="/search"
              className="flex items-center gap-1.5 text-navy-600 hover:text-gold-600 font-medium transition-colors"
            >
              <Search className="w-5 h-5" />
            </Link>
            {session ? (
              <>
                <Link
                  to="/submit"
                  className="flex items-center gap-1.5 text-navy-700 hover:text-gold-600 font-semibold transition-colors"
                >
                  <PlusCircle className="w-5 h-5" />
                  أضف عقار
                </Link>
                <Link
                  to="/my-listings"
                  className="flex items-center gap-1.5 text-navy-700 hover:text-gold-600 font-semibold transition-colors"
                >
                  <List className="w-5 h-5" />
                  عقاراتي
                </Link>
                {isAdmin && (
                  <Link
                    to="/admin"
                    className="flex items-center gap-1.5 text-navy-700 hover:text-gold-600 font-semibold transition-colors"
                  >
                    <LayoutDashboard className="w-5 h-5" />
                    لوحة التحكم
                  </Link>
                )}
                <div className="flex items-center gap-2 px-3 py-2 bg-navy-50 rounded-lg">
                  <User className="w-4 h-4 text-navy-500" />
                  <span className="text-sm font-medium text-navy-800">
                    {profile?.display_name || 'حسابي'}
                  </span>
                </div>
                <button
                  onClick={handleSignOut}
                  className="flex items-center gap-1.5 text-error-600 hover:text-error-700 font-medium transition-colors"
                >
                  <LogOut className="w-5 h-5" />
                  خروج
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="text-navy-700 hover:text-gold-600 font-semibold transition-colors">
                  تسجيل الدخول
                </Link>
                <Link to="/register" className="btn-primary text-sm">
                  حساب جديد
                </Link>
              </>
            )}
          </div>

          {/* Mobile toggle */}
          <button
            className="lg:hidden p-2 text-navy-800"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="القائمة"
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-navy-100 bg-white animate-fade-in">
          <div className="px-4 pt-4">
            <Link
              to="/"
              onClick={() => setMobileOpen(false)}
              className="flex items-center gap-3 rounded-xl bg-navy-50 p-2"
            >
              <img
                src="/images/1791649155527.jpg"
                alt="عقارك مباشر - Aqarak Mobasher"
                className="h-14 w-14 rounded-lg object-cover shadow-sm"
              />
              <span className="text-sm font-bold text-navy-900">عقارك مباشر</span>
            </Link>
          </div>
          <div className="px-4 py-4 space-y-2">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setMobileOpen(false)}
                className="block py-2.5 px-3 rounded-lg text-navy-800 hover:bg-navy-50 font-semibold transition-colors"
              >
                {link.label}
              </Link>
            ))}
            <div className="flex items-center gap-3 px-3 py-2">
              <a href={FACEBOOK_URL} target="_blank" rel="noopener noreferrer" aria-label="فيسبوك" className="flex items-center gap-2 text-navy-700 hover:text-gold-600 font-semibold">
                <Facebook className="h-5 w-5" />
                فيسبوك
              </a>
              <a href={INSTAGRAM_URL} target="_blank" rel="noopener noreferrer" aria-label="انستجرام" className="flex items-center gap-2 text-navy-700 hover:text-gold-600 font-semibold">
                <Instagram className="h-5 w-5" />
                انستجرام
              </a>
            </div>
            <hr className="border-navy-100" />
            {session ? (
              <>
                <Link
                  to="/submit"
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center gap-2 py-2.5 px-3 rounded-lg text-navy-800 hover:bg-navy-50 font-semibold"
                >
                  <PlusCircle className="w-5 h-5" />
                  أضف عقار
                </Link>
                <Link
                  to="/my-listings"
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center gap-2 py-2.5 px-3 rounded-lg text-navy-800 hover:bg-navy-50 font-semibold"
                >
                  <List className="w-5 h-5" />
                  عقاراتي
                </Link>
                {isAdmin && (
                  <Link
                    to="/admin"
                    onClick={() => setMobileOpen(false)}
                    className="flex items-center gap-2 py-2.5 px-3 rounded-lg text-navy-800 hover:bg-navy-50 font-semibold"
                  >
                    <LayoutDashboard className="w-5 h-5" />
                    لوحة التحكم
                  </Link>
                )}
                <div className="py-2 px-3 text-sm text-navy-600">
                  مرحباً، {profile?.display_name || 'مستخدم'}
                </div>
                <button
                  onClick={handleSignOut}
                  className="flex items-center gap-2 w-full py-2.5 px-3 rounded-lg text-error-600 hover:bg-error-50 font-semibold"
                >
                  <LogOut className="w-5 h-5" />
                  تسجيل الخروج
                </button>
              </>
            ) : (
              <div className="flex flex-col gap-2 pt-2">
                <Link
                  to="/login"
                  onClick={() => setMobileOpen(false)}
                  className="btn-outline text-center"
                >
                  تسجيل الدخول
                </Link>
                <Link
                  to="/register"
                  onClick={() => setMobileOpen(false)}
                  className="btn-primary text-center"
                >
                  إنشاء حساب جديد
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
