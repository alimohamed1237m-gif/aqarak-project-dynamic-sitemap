import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Twitter, Instagram, MessageCircle } from 'lucide-react';
import {
  ADMIN_PHONE,
  ADMIN_WHATSAPP_NUMBER,
  BUSINESS_ADDRESS,
  FACEBOOK_URL,
  INSTAGRAM_URL,
  SUPPORT_EMAIL,
} from '@/lib/constants';

export default function Footer() {
  return (
    <footer className="bg-navy-900 text-navy-100 mt-16">
      <div className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <Link to="/" className="inline-flex rounded-2xl bg-white p-2 shadow-lg" aria-label="عقارك مباشر">
              <img
                src="/images/1791649155527.jpg"
                alt="عقارك مباشر - Aqarak Mobasher"
                className="h-28 w-28 rounded-xl object-cover sm:h-32 sm:w-32"
              />
            </Link>
            <p className="text-sm text-navy-300 leading-relaxed">
              منصة عقارية مصرية تربط البائع بالمشتري مباشرة. تصفح آلاف العقارات في جميع المحافظات المصرية.
            </p>
          </div>

          {/* Quick links */}
          <div>
            <h3 className="text-white font-bold mb-4">روابط سريعة</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/" className="text-navy-300 hover:text-gold-400 transition-colors">الرئيسية</Link></li>
              <li><Link to="/search" className="text-navy-300 hover:text-gold-400 transition-colors">البحث عن عقار</Link></li>
              <li><Link to="/about" className="text-navy-300 hover:text-gold-400 transition-colors">من نحن</Link></li>
              <li><Link to="/contact" className="text-navy-300 hover:text-gold-400 transition-colors">اتصل بنا</Link></li>
              <li><Link to="/submit" className="text-navy-300 hover:text-gold-400 transition-colors">أضف عقارك</Link></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-white font-bold mb-4">الشروط والأحكام</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/privacy" className="text-navy-300 hover:text-gold-400 transition-colors">سياسة الخصوصية</Link></li>
              <li><Link to="/terms" className="text-navy-300 hover:text-gold-400 transition-colors">شروط الاستخدام</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-bold mb-4">تواصل معنا</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2 text-navy-300">
                <Phone className="w-4 h-4 text-gold-500" />
                <a href={`tel:${ADMIN_PHONE}`} dir="ltr" className="hover:text-gold-400 transition-colors">{ADMIN_PHONE}</a>
              </li>
              <li className="flex items-center gap-2 text-navy-300">
                <Mail className="w-4 h-4 text-gold-500" />
                <a href={`mailto:${SUPPORT_EMAIL}`} dir="ltr" className="hover:text-gold-400 transition-colors">{SUPPORT_EMAIL}</a>
              </li>
              <li className="flex items-center gap-2 text-navy-300">
                <MapPin className="w-4 h-4 text-gold-500" />
                {BUSINESS_ADDRESS}
              </li>
            </ul>
            <a
              href={`https://wa.me/${ADMIN_WHATSAPP_NUMBER}?text=${encodeURIComponent('مرحباً، أود الاستفسار عن خدمات عقارك مباشر')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 mt-4 rounded-lg bg-success-500 px-4 py-2 text-sm font-semibold text-white hover:bg-success-600 transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              تواصل معنا عبر واتساب
            </a>
            <div className="flex gap-3 mt-4">
              <a
                href={FACEBOOK_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 bg-white/10 rounded-lg flex items-center justify-center hover:bg-gold-500 hover:text-navy-900 transition-colors"
                aria-label="فيسبوك"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-9 h-9 bg-white/10 rounded-lg flex items-center justify-center hover:bg-gold-500 hover:text-navy-900 transition-colors" aria-label="تويتر">
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href={INSTAGRAM_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 bg-white/10 rounded-lg flex items-center justify-center hover:bg-gold-500 hover:text-navy-900 transition-colors"
                aria-label="انستجرام"
              >
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 mt-8 pt-6 text-center text-sm text-navy-400">
          <p>© 2026 عقارك مباشر - جميع الحقوق محفوظة</p>
        </div>
      </div>
    </footer>
  );
}
