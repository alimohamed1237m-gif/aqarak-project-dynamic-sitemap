import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { PlusCircle, Building2, Loader2, Clock, CheckCircle, XCircle, Eye, Trash2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { Property } from '@/types';
import { STATUS_LABELS, formatPrice, PROPERTY_TYPE_LABELS, LISTING_TYPE_LABELS } from '@/lib/constants';

export default function MyListings() {
  const { session } = useAuth();
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState<string | null>(null);

  useEffect(() => {
    async function loadListings() {
      if (!session) return;
      const { data } = await supabase
        .from('properties')
        .select('*, property_images(image_url, sort_order)')
        .eq('user_id', session.user.id)
        .order('created_at', { ascending: false });
      setProperties(data as Property[] || []);
      setLoading(false);
    }
    loadListings();
  }, [session]);

  const handleDelete = async (id: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا العقار؟')) return;
    setDeleting(id);
    await supabase.from('properties').delete().eq('id', id);
    setProperties((prev) => prev.filter((p) => p.id !== id));
    setDeleting(null);
  };

  const statusIcons: Record<string, typeof Clock> = {
    pending: Clock,
    approved: CheckCircle,
    rejected: XCircle,
    hidden: Eye,
  };

  const statusColors: Record<string, string> = {
    pending: 'text-warning-600 bg-warning-50',
    approved: 'text-success-600 bg-success-50',
    rejected: 'text-error-600 bg-error-50',
    hidden: 'text-navy-600 bg-navy-50',
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-gold-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">عقاراتي</h1>
          <p className="text-navy-500 text-sm mt-1">{properties.length} عقار</p>
        </div>
        <Link to="/submit" className="btn-primary flex items-center gap-2">
          <PlusCircle className="w-5 h-5" />
          أضف عقار
        </Link>
      </div>

      {properties.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-20 h-20 bg-navy-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <Building2 className="w-10 h-10 text-navy-300" />
          </div>
          <h3 className="text-xl font-bold text-navy-800 mb-2">لا توجد عقارات</h3>
          <p className="text-navy-500 mb-4">لم تقم بإضافة أي عقار بعد</p>
          <Link to="/submit" className="btn-primary">أضف عقارك الأول</Link>
        </div>
      ) : (
        <div className="space-y-3">
          {properties.map((property) => {
            const StatusIcon = statusIcons[property.status];
            const imageUrl = property.main_image_url || property.property_images?.[0]?.image_url;

            return (
              <div key={property.id} className="bg-white border border-navy-100 rounded-2xl p-4 flex gap-4 items-center hover:shadow-md transition-shadow">
                {/* Image */}
                <Link to={`/property/${property.id}`} className="shrink-0">
                  {imageUrl ? (
                    <img src={imageUrl} alt={property.title} className="w-24 h-24 rounded-xl object-cover" />
                  ) : (
                    <div className="w-24 h-24 bg-navy-50 rounded-xl flex items-center justify-center">
                      <Building2 className="w-8 h-8 text-navy-300" />
                    </div>
                  )}
                </Link>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <Link to={`/property/${property.id}`}>
                    <h3 className="font-bold text-navy-900 truncate hover:text-gold-600 transition-colors">
                      {property.title}
                    </h3>
                  </Link>
                  <p className="text-sm text-navy-500 truncate">
                    {property.governorate} - {property.city} • {PROPERTY_TYPE_LABELS[property.property_type]} • {LISTING_TYPE_LABELS[property.listing_type]}
                  </p>
                  <p className="text-gold-600 font-bold mt-1">{formatPrice(property.price, property.currency)}</p>
                </div>

                {/* Status */}
                <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-semibold shrink-0 ${statusColors[property.status]}`}>
                  <StatusIcon className="w-4 h-4" />
                  <span className="hidden sm:inline">{STATUS_LABELS[property.status]}</span>
                </div>

                {/* Delete */}
                <button
                  onClick={() => handleDelete(property.id)}
                  disabled={deleting === property.id}
                  className="shrink-0 w-10 h-10 flex items-center justify-center bg-error-50 text-error-600 rounded-lg hover:bg-error-100 transition-colors disabled:opacity-50"
                >
                  {deleting === property.id ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <Trash2 className="w-5 h-5" />
                  )}
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
