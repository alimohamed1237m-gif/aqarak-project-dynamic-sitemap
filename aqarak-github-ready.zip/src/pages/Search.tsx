import { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SlidersHorizontal, X, Search as SearchIcon } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Property, PropertyType, ListingType } from '@/types';
import {
  GOVERNORATES, PROPERTY_TYPES, LISTING_TYPES,
} from '@/lib/constants';
import PropertyCard from '@/components/PropertyCard';

interface Filters {
  governorate: string;
  city: string;
  property_type: string;
  listing_type: string;
  min_price: string;
  max_price: string;
  min_area: string;
  max_area: string;
  bedrooms: string;
}

const EMPTY_FILTERS: Filters = {
  governorate: '',
  city: '',
  property_type: '',
  listing_type: '',
  min_price: '',
  max_price: '',
  min_area: '',
  max_area: '',
  bedrooms: '',
};

export default function Search() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<Filters>({ ...EMPTY_FILTERS });
  const [resultCount, setResultCount] = useState(0);

  // Initialize filters from URL params
  useEffect(() => {
    setFilters({
      ...EMPTY_FILTERS,
      governorate: searchParams.get('governorate') || '',
      property_type: searchParams.get('type') || '',
      listing_type: searchParams.get('listing') || '',
    });
  }, [searchParams]);

  const fetchProperties = useCallback(async () => {
    setLoading(true);
    let query = supabase
      .from('properties')
      .select('*, property_images(image_url, sort_order)')
      .eq('status', 'approved');

    if (filters.governorate) query = query.eq('governorate', filters.governorate);
    if (filters.city) query = query.ilike('city', `%${filters.city}%`);
    if (filters.property_type) query = query.eq('property_type', filters.property_type as PropertyType);
    if (filters.listing_type) query = query.eq('listing_type', filters.listing_type as ListingType);
    if (filters.min_price) query = query.gte('price', parseFloat(filters.min_price));
    if (filters.max_price) query = query.lte('price', parseFloat(filters.max_price));
    if (filters.min_area) query = query.gte('area_sqm', parseFloat(filters.min_area));
    if (filters.max_area) query = query.lte('area_sqm', parseFloat(filters.max_area));
    if (filters.bedrooms) query = query.gte('bedrooms', parseInt(filters.bedrooms));

    query = query.order('created_at', { ascending: false });
    const { data } = await query;
    setProperties(data as Property[] || []);
    setResultCount(data?.length || 0);
    setLoading(false);
  }, [filters]);

  useEffect(() => {
    fetchProperties();
  }, [fetchProperties]);

  const handleFilterChange = (key: keyof Filters, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({ ...EMPTY_FILTERS });
    setSearchParams({});
  };

  const hasActiveFilters = Object.values(filters).some((v) => v !== '');

  return (
    <div className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Page header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">البحث عن عقار</h1>
          <p className="text-navy-500 text-sm mt-1">
            {loading ? 'جاري البحث...' : `${resultCount} عقار متاح`}
          </p>
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="lg:hidden flex items-center gap-2 px-4 py-2.5 bg-navy-800 text-white rounded-lg font-semibold"
        >
          <SlidersHorizontal className="w-5 h-5" />
          فلترة
        </button>
      </div>

      <div className="flex gap-6">
        {/* Filters sidebar */}
        <aside
          className={`${showFilters ? 'fixed inset-0 z-50 bg-black/50 lg:bg-transparent lg:static lg:z-auto' : 'hidden'} lg:block w-full lg:w-72 shrink-0`}
          onClick={() => setShowFilters(false)}
        >
          <div
            className="bg-white lg:bg-navy-50 lg:rounded-2xl p-5 lg:p-6 h-full lg:h-auto max-w-sm lg:max-w-none mr-auto lg:mr-0 overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold text-navy-900 flex items-center gap-2">
                <SlidersHorizontal className="w-5 h-5 text-gold-500" />
                الفلاتر
              </h2>
              <div className="flex items-center gap-2">
                {hasActiveFilters && (
                  <button
                    onClick={clearFilters}
                    className="text-sm text-error-600 hover:text-error-700 font-medium"
                  >
                    مسح الكل
                  </button>
                )}
                <button
                  onClick={() => setShowFilters(false)}
                  className="lg:hidden p-1 text-navy-600"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="space-y-4">
              {/* Governorate */}
              <div>
                <label className="block text-sm font-semibold text-navy-700 mb-1.5">المحافظة</label>
                <select
                  value={filters.governorate}
                  onChange={(e) => handleFilterChange('governorate', e.target.value)}
                  className="input-field"
                >
                  <option value="">كل المحافظات</option>
                  {GOVERNORATES.map((g) => (
                    <option key={g} value={g}>{g}</option>
                  ))}
                </select>
              </div>

              {/* City */}
              <div>
                <label className="block text-sm font-semibold text-navy-700 mb-1.5">المدينة / المنطقة</label>
                <input
                  type="text"
                  value={filters.city}
                  onChange={(e) => handleFilterChange('city', e.target.value)}
                  placeholder="مثال: التجمع الخامس"
                  className="input-field"
                />
              </div>

              {/* Property type */}
              <div>
                <label className="block text-sm font-semibold text-navy-700 mb-1.5">نوع العقار</label>
                <select
                  value={filters.property_type}
                  onChange={(e) => handleFilterChange('property_type', e.target.value)}
                  className="input-field"
                >
                  <option value="">كل الأنواع</option>
                  {PROPERTY_TYPES.map((t) => (
                    <option key={t.value} value={t.value}>{t.label}</option>
                  ))}
                </select>
              </div>

              {/* Listing type */}
              <div>
                <label className="block text-sm font-semibold text-navy-700 mb-1.5">نوع العملية</label>
                <div className="flex gap-2">
                  {LISTING_TYPES.map((t) => (
                    <button
                      key={t.value}
                      onClick={() => handleFilterChange('listing_type', filters.listing_type === t.value ? '' : t.value)}
                      className={`flex-1 py-2.5 rounded-lg font-semibold text-sm transition-colors ${
                        filters.listing_type === t.value
                          ? 'bg-navy-800 text-white'
                          : 'bg-white text-navy-700 border border-navy-200 hover:border-navy-400'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price range */}
              <div>
                <label className="block text-sm font-semibold text-navy-700 mb-1.5">السعر (ج.م)</label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    value={filters.min_price}
                    onChange={(e) => handleFilterChange('min_price', e.target.value)}
                    placeholder="من"
                    className="input-field"
                  />
                  <input
                    type="number"
                    value={filters.max_price}
                    onChange={(e) => handleFilterChange('max_price', e.target.value)}
                    placeholder="إلى"
                    className="input-field"
                  />
                </div>
              </div>

              {/* Area range */}
              <div>
                <label className="block text-sm font-semibold text-navy-700 mb-1.5">المساحة (م²)</label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    value={filters.min_area}
                    onChange={(e) => handleFilterChange('min_area', e.target.value)}
                    placeholder="من"
                    className="input-field"
                  />
                  <input
                    type="number"
                    value={filters.max_area}
                    onChange={(e) => handleFilterChange('max_area', e.target.value)}
                    placeholder="إلى"
                    className="input-field"
                  />
                </div>
              </div>

              {/* Bedrooms */}
              <div>
                <label className="block text-sm font-semibold text-navy-700 mb-1.5">غرف النوم</label>
                <select
                  value={filters.bedrooms}
                  onChange={(e) => handleFilterChange('bedrooms', e.target.value)}
                  className="input-field"
                >
                  <option value="">الكل</option>
                  <option value="1">1+ غرفة</option>
                  <option value="2">2+ غرفة</option>
                  <option value="3">3+ غرف</option>
                  <option value="4">4+ غرف</option>
                  <option value="5">5+ غرف</option>
                </select>
              </div>
            </div>
          </div>
        </aside>

        {/* Results */}
        <div className="flex-1">
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="card">
                  <div className="h-52 skeleton" />
                  <div className="p-4 space-y-3">
                    <div className="h-5 skeleton rounded" />
                    <div className="h-4 w-2/3 skeleton rounded" />
                    <div className="h-8 skeleton rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : properties.length === 0 ? (
            <div className="text-center py-20">
              <div className="w-20 h-20 bg-navy-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <SearchIcon className="w-10 h-10 text-navy-300" />
              </div>
              <h3 className="text-xl font-bold text-navy-800 mb-2">لا توجد نتائج</h3>
              <p className="text-navy-500 mb-4">جرّب تعديل الفلاتر للعثور على عقارات أخرى</p>
              {hasActiveFilters && (
                <button onClick={clearFilters} className="btn-outline">
                  مسح الفلاتر
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {properties.map((p) => (
                <PropertyCard key={p.id} property={p} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
