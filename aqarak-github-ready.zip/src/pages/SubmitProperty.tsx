import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2, AlertCircle, CheckCircle, ImagePlus, X } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import {
  GOVERNORATES, PROPERTY_TYPES, LISTING_TYPES, CURRENCIES,
} from '@/lib/constants';
import type { PropertyType, ListingType, Currency } from '@/types';

interface FormData {
  title: string;
  description: string;
  price: string;
  currency: Currency;
  property_type: PropertyType;
  listing_type: ListingType;
  governorate: string;
  city: string;
  area_name: string;
  address: string;
  area_sqm: string;
  bedrooms: string;
  bathrooms: string;
  contact_phone: string;
  contact_whatsapp: string;
  main_image_url: string;
  image_urls: string[];
}

const EMPTY_FORM: FormData = {
  title: '',
  description: '',
  price: '',
  currency: 'EGP',
  property_type: 'apartment',
  listing_type: 'sale',
  governorate: '',
  city: '',
  area_name: '',
  address: '',
  area_sqm: '',
  bedrooms: '',
  bathrooms: '',
  contact_phone: '',
  contact_whatsapp: '',
  main_image_url: '',
  image_urls: [],
};

export default function SubmitProperty() {
  const navigate = useNavigate();
  const [form, setForm] = useState<FormData>({ ...EMPTY_FORM });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (key: keyof FormData, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const addImageUrl = () => {
    setForm((prev) => ({ ...prev, image_urls: [...prev.image_urls, ''] }));
  };

  const updateImageUrl = (index: number, value: string) => {
    setForm((prev) => ({
      ...prev,
      image_urls: prev.image_urls.map((url, i) => (i === index ? value : url)),
    }));
  };

  const removeImageUrl = (index: number) => {
    setForm((prev) => ({
      ...prev,
      image_urls: prev.image_urls.filter((_, i) => i !== index),
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!form.title || !form.price || !form.governorate || !form.city) {
      setError('يرجى ملء الحقول المطلوبة: العنوان، السعر، المحافظة، المدينة.');
      return;
    }

    setLoading(true);

    try {
      const { data, error: insertError } = await supabase
        .from('properties')
        .insert({
          title: form.title,
          description: form.description || null,
          price: parseFloat(form.price),
          currency: form.currency,
          property_type: form.property_type,
          listing_type: form.listing_type,
          governorate: form.governorate,
          city: form.city,
          area_name: form.area_name || null,
          address: form.address || null,
          area_sqm: form.area_sqm ? parseFloat(form.area_sqm) : null,
          bedrooms: form.bedrooms ? parseInt(form.bedrooms) : null,
          bathrooms: form.bathrooms ? parseInt(form.bathrooms) : null,
          contact_phone: form.contact_phone || null,
          contact_whatsapp: form.contact_whatsapp || null,
          main_image_url: form.main_image_url || null,
        })
        .select('id')
        .single();

      if (insertError) throw insertError;

      const propertyId = data.id;

      // Insert gallery images
      const validImages = form.image_urls.filter((url) => url.trim());
      if (validImages.length > 0) {
        const imageRows = validImages.map((url, i) => ({
          property_id: propertyId,
          image_url: url.trim(),
          sort_order: i,
        }));
        const { error: imgError } = await supabase
          .from('property_images')
          .insert(imageRows);
        if (imgError) throw imgError;
      }

      setSuccess(true);
      setForm({ ...EMPTY_FORM });
    } catch (cause) {
      console.error('Property submission failed', cause);
      setError('تعذر إضافة العقار. حاول مرة أخرى.');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <div className="w-20 h-20 bg-success-50 rounded-full flex items-center justify-center mx-auto mb-4">
          <CheckCircle className="w-10 h-10 text-success-500" />
        </div>
        <h1 className="text-2xl font-bold text-navy-900 mb-3">تم إرسال عقارك بنجاح</h1>
        <p className="text-navy-600 mb-2">
          عقارك الآن قيد المراجعة. سيظهر على الموقع بعد موافقة فريق الإدارة.
        </p>
        <p className="text-navy-500 text-sm mb-8">
          يمكنك متابعة حالة عقارك من صفحة "عقاراتي"
        </p>
        <div className="flex gap-3 justify-center">
          <button onClick={() => setSuccess(false)} className="btn-primary">
            أضف عقار آخر
          </button>
          <button onClick={() => navigate('/my-listings')} className="btn-outline">
            عقاراتي
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-navy-900">إضافة عقار جديد</h1>
        <p className="text-navy-500 text-sm mt-1">
          املأ التفاصيل أدناه. سيتم مراجعة عقارك قبل نشره.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {error && (
          <div className="flex items-center gap-2 bg-error-50 text-error-700 p-3 rounded-lg text-sm">
            <AlertCircle className="w-5 h-5 shrink-0" />
            {error}
          </div>
        )}

        {/* Basic info */}
        <div className="bg-white border border-navy-100 rounded-2xl p-6 space-y-4">
          <h2 className="font-bold text-navy-900">المعلومات الأساسية</h2>

          <div>
            <label className="block text-sm font-semibold text-navy-700 mb-1.5">
              عنوان الإعلان <span className="text-error-500">*</span>
            </label>
            <input
              type="text"
              value={form.title}
              onChange={(e) => handleChange('title', e.target.value)}
              required
              placeholder="مثال: شقة 150م بالتشطيب سوبر لوكس - التجمع الخامس"
              className="input-field"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-navy-700 mb-1.5">نوع العقار</label>
              <select
                value={form.property_type}
                onChange={(e) => handleChange('property_type', e.target.value)}
                className="input-field"
              >
                {PROPERTY_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-navy-700 mb-1.5">نوع العملية</label>
              <select
                value={form.listing_type}
                onChange={(e) => handleChange('listing_type', e.target.value)}
                className="input-field"
              >
                {LISTING_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-navy-700 mb-1.5">الوصف</label>
            <textarea
              value={form.description}
              onChange={(e) => handleChange('description', e.target.value)}
              rows={4}
              placeholder="اكتب وصفاً تفصيلياً للعقار..."
              className="input-field resize-none"
            />
          </div>
        </div>

        {/* Price */}
        <div className="bg-white border border-navy-100 rounded-2xl p-6 space-y-4">
          <h2 className="font-bold text-navy-900">السعر</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-navy-700 mb-1.5">
                السعر <span className="text-error-500">*</span>
              </label>
              <input
                type="number"
                value={form.price}
                onChange={(e) => handleChange('price', e.target.value)}
                required
                placeholder="0"
                className="input-field"
                dir="ltr"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-navy-700 mb-1.5">العملة</label>
              <select
                value={form.currency}
                onChange={(e) => handleChange('currency', e.target.value)}
                className="input-field"
              >
                {CURRENCIES.map((c) => (
                  <option key={c.value} value={c.value}>{c.label}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Location */}
        <div className="bg-white border border-navy-100 rounded-2xl p-6 space-y-4">
          <h2 className="font-bold text-navy-900">الموقع</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-navy-700 mb-1.5">
                المحافظة <span className="text-error-500">*</span>
              </label>
              <select
                value={form.governorate}
                onChange={(e) => handleChange('governorate', e.target.value)}
                required
                className="input-field"
              >
                <option value="">اختر المحافظة</option>
                {GOVERNORATES.map((g) => (
                  <option key={g} value={g}>{g}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-navy-700 mb-1.5">
                المدينة <span className="text-error-500">*</span>
              </label>
              <input
                type="text"
                value={form.city}
                onChange={(e) => handleChange('city', e.target.value)}
                required
                placeholder="مثال: التجمع الخامس"
                className="input-field"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-semibold text-navy-700 mb-1.5">المنطقة / الكمبوند</label>
            <input
              type="text"
              value={form.area_name}
              onChange={(e) => handleChange('area_name', e.target.value)}
              placeholder="مثال: ميفيدا"
              className="input-field"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-navy-700 mb-1.5">العنوان التفصيلي</label>
            <input
              type="text"
              value={form.address}
              onChange={(e) => handleChange('address', e.target.value)}
              placeholder="العنوان بالتفصيل"
              className="input-field"
            />
          </div>
        </div>

        {/* Specs */}
        <div className="bg-white border border-navy-100 rounded-2xl p-6 space-y-4">
          <h2 className="font-bold text-navy-900">المواصفات</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-semibold text-navy-700 mb-1.5">المساحة (م²)</label>
              <input
                type="number"
                value={form.area_sqm}
                onChange={(e) => handleChange('area_sqm', e.target.value)}
                placeholder="0"
                className="input-field"
                dir="ltr"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-navy-700 mb-1.5">غرف النوم</label>
              <input
                type="number"
                value={form.bedrooms}
                onChange={(e) => handleChange('bedrooms', e.target.value)}
                placeholder="0"
                className="input-field"
                dir="ltr"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-navy-700 mb-1.5">الحمامات</label>
              <input
                type="number"
                value={form.bathrooms}
                onChange={(e) => handleChange('bathrooms', e.target.value)}
                placeholder="0"
                className="input-field"
                dir="ltr"
              />
            </div>
          </div>
        </div>

        {/* Contact */}
        <div className="bg-white border border-navy-100 rounded-2xl p-6 space-y-4">
          <h2 className="font-bold text-navy-900">بيانات التواصل</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-navy-700 mb-1.5">رقم الهاتف</label>
              <input
                type="tel"
                value={form.contact_phone}
                onChange={(e) => handleChange('contact_phone', e.target.value)}
                placeholder="01012345678"
                className="input-field"
                dir="ltr"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-navy-700 mb-1.5">رقم واتساب</label>
              <input
                type="tel"
                value={form.contact_whatsapp}
                onChange={(e) => handleChange('contact_whatsapp', e.target.value)}
                placeholder="201012345678"
                className="input-field"
                dir="ltr"
              />
            </div>
          </div>
        </div>

        {/* Images */}
        <div className="bg-white border border-navy-100 rounded-2xl p-6 space-y-4">
          <h2 className="font-bold text-navy-900">الصور</h2>
          <p className="text-sm text-navy-500">أضف روابط صور العقار (من الإنترنت).</p>

          <div>
            <label className="block text-sm font-semibold text-navy-700 mb-1.5">الصورة الرئيسية</label>
            <input
              type="url"
              value={form.main_image_url}
              onChange={(e) => handleChange('main_image_url', e.target.value)}
              placeholder="https://..."
              className="input-field"
              dir="ltr"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-navy-700 mb-1.5">صور إضافية للمعرض</label>
            {form.image_urls.map((url, i) => (
              <div key={i} className="flex gap-2 mb-2">
                <input
                  type="url"
                  value={url}
                  onChange={(e) => updateImageUrl(i, e.target.value)}
                  placeholder="https://..."
                  className="input-field"
                  dir="ltr"
                />
                <button
                  type="button"
                  onClick={() => removeImageUrl(i)}
                  className="shrink-0 w-11 h-11 flex items-center justify-center bg-error-50 text-error-600 rounded-lg hover:bg-error-100 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            ))}
            <button
              type="button"
              onClick={addImageUrl}
              className="flex items-center gap-1.5 text-gold-600 hover:text-gold-700 font-semibold text-sm transition-colors"
            >
              <ImagePlus className="w-5 h-5" />
              إضافة صورة
            </button>
          </div>
        </div>

        {/* Submit */}
        <button
          type="submit"
          disabled={loading}
          className="btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-60"
        >
          {loading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (
            'إرسال العقار للمراجعة'
          )}
        </button>
      </form>
    </div>
  );
}
