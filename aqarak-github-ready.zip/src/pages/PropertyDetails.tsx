import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  MapPin, BedDouble, Bath, Maximize, ArrowRight,
  ChevronRight, ChevronLeft, Building2, Calendar, Tag, MessageCircle,
  CheckCircle, XCircle, Clock, Eye, Send, Loader2, AlertCircle, ShieldCheck,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import type { Property, PropertyImage } from '@/types';
import {
  formatPrice, PROPERTY_TYPE_LABELS, LISTING_TYPE_LABELS,
  STATUS_LABELS, CURRENCY_SYMBOLS, ADMIN_WHATSAPP_NUMBER,
} from '@/lib/constants';
import PropertyCard from '@/components/PropertyCard';

export default function PropertyDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [property, setProperty] = useState<Property | null>(null);
  const [images, setImages] = useState<PropertyImage[]>([]);
  const [similar, setSimilar] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeImage, setActiveImage] = useState(0);
  const [error, setError] = useState(false);

  // Inquiry form state
  const [inquiryName, setInquiryName] = useState('');
  const [inquiryPhone, setInquiryPhone] = useState('');
  const [inquiryEmail, setInquiryEmail] = useState('');
  const [inquiryMessage, setInquiryMessage] = useState('');
  const [inquirySending, setInquirySending] = useState(false);
  const [inquirySent, setInquirySent] = useState(false);
  const [inquiryError, setInquiryError] = useState('');

  useEffect(() => {
    async function loadProperty() {
      setLoading(true);
      setError(false);
      setActiveImage(0);

      const { data, error: queryError } = await supabase
        .from('properties')
        .select('*')
        .eq('id', id!)
        .maybeSingle();

      if (queryError || !data) {
        setError(true);
        setLoading(false);
        return;
      }

      const prop = data as Property;
      setProperty(prop);

      const isOwner = profile?.id === prop.user_id;
      const isAdmin = profile?.role === 'admin';
      if (prop.status !== 'approved' && !isOwner && !isAdmin) {
        setError(true);
        setLoading(false);
        return;
      }

      const { data: imgData } = await supabase
        .from('property_images')
        .select('*')
        .eq('property_id', id!)
        .order('sort_order', { ascending: true });

      setImages(imgData as PropertyImage[] || []);

      const { data: similarData } = await supabase
        .from('properties')
        .select('*, property_images(image_url, sort_order)')
        .eq('status', 'approved')
        .eq('property_type', prop.property_type)
        .neq('id', id!)
        .limit(4);

      setSimilar(similarData as Property[] || []);
      setLoading(false);
    }

    if (id) loadProperty();
  }, [id, profile]);

  const handleInquirySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setInquiryError('');

    if (!inquiryName.trim()) {
      setInquiryError('يرجى إدخال الاسم.');
      return;
    }

    setInquirySending(true);
    try {
      const { error: insertError } = await supabase
        .from('inquiries')
        .insert({
          property_id: id,
          name: inquiryName.trim(),
          phone: inquiryPhone.trim() || null,
          email: inquiryEmail.trim() || null,
          message: inquiryMessage.trim() || null,
        });

      if (insertError) throw insertError;

      setInquirySent(true);
      setInquiryName('');
      setInquiryPhone('');
      setInquiryEmail('');
      setInquiryMessage('');
    } catch (cause) {
      console.error('Inquiry submission failed', cause);
      setInquiryError('تعذر إرسال الطلب. حاول مرة أخرى.');
    } finally {
      setInquirySending(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="h-80 skeleton rounded-2xl mb-6" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <div className="h-8 skeleton rounded" />
            <div className="h-4 skeleton rounded w-2/3" />
            <div className="h-32 skeleton rounded" />
          </div>
          <div className="h-64 skeleton rounded-2xl" />
        </div>
      </div>
    );
  }

  if (error || !property) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <div className="w-20 h-20 bg-error-50 rounded-full flex items-center justify-center mx-auto mb-4">
          <XCircle className="w-10 h-10 text-error-500" />
        </div>
        <h2 className="text-xl font-bold text-navy-800 mb-2">العقار غير متاح</h2>
        <p className="text-navy-500 mb-4">قد يكون هذا العقار قد حُذف أو غير معروض</p>
        <Link to="/search" className="btn-primary">العودة للبحث</Link>
      </div>
    );
  }

  const allImages = [
    ...(property.main_image_url ? [property.main_image_url] : []),
    ...images.map((img) => img.image_url),
  ];
  const uniqueImages = [...new Set(allImages)];

  const adminWhatsappMessage = `مرحباً، أود الاستفسار عن العقار: ${property.title} (رقم: ${property.id.slice(0, 8)})`;
  const adminWhatsappUrl = `https://wa.me/${ADMIN_WHATSAPP_NUMBER}?text=${encodeURIComponent(adminWhatsappMessage)}`;

  const statusInfo: Record<string, { icon: typeof CheckCircle; color: string; bg: string }> = {
    approved: { icon: CheckCircle, color: 'text-success-600', bg: 'bg-success-50' },
    pending: { icon: Clock, color: 'text-warning-600', bg: 'bg-warning-50' },
    rejected: { icon: XCircle, color: 'text-error-600', bg: 'bg-error-50' },
    hidden: { icon: Eye, color: 'text-navy-600', bg: 'bg-navy-50' },
  };
  const StatusIcon = statusInfo[property.status]?.icon;

  const specs = [
    { icon: BedDouble, label: 'غرف النوم', value: property.bedrooms },
    { icon: Bath, label: 'الحمامات', value: property.bathrooms },
    { icon: Maximize, label: 'المساحة', value: property.area_sqm ? `${property.area_sqm} م²` : null },
    { icon: Building2, label: 'النوع', value: PROPERTY_TYPE_LABELS[property.property_type] },
  ].filter((s) => s.value != null);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-1.5 text-sm text-navy-500 mb-4">
        <Link to="/" className="hover:text-gold-600">الرئيسية</Link>
        <ChevronLeft className="w-4 h-4" />
        <Link to="/search" className="hover:text-gold-600">البحث</Link>
        <ChevronLeft className="w-4 h-4" />
        <span className="text-navy-800 font-medium truncate">{property.title}</span>
      </nav>

      {/* Status banner for owner/admin */}
      {property.status !== 'approved' && (
        <div className={`mb-4 p-4 rounded-xl flex items-center gap-3 ${statusInfo[property.status].bg}`}>
          {StatusIcon && <StatusIcon className={`w-5 h-5 ${statusInfo[property.status].color}`} />}
          <span className={`font-semibold ${statusInfo[property.status].color}`}>
            حالة العقار: {STATUS_LABELS[property.status]}
          </span>
        </div>
      )}

      {/* Gallery */}
      <div className="mb-6">
        {uniqueImages.length > 0 ? (
          <>
            <div className="relative h-64 sm:h-80 md:h-96 rounded-2xl overflow-hidden bg-navy-100">
              <img
                src={uniqueImages[activeImage]}
                alt={property.title}
                className="w-full h-full object-cover"
              />
              {uniqueImages.length > 1 && (
                <>
                  <button
                    onClick={() => setActiveImage((prev) => (prev === 0 ? uniqueImages.length - 1 : prev - 1))}
                    className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/80 hover:bg-white rounded-full flex items-center justify-center shadow-md transition-colors"
                  >
                    <ChevronRight className="w-6 h-6 text-navy-800" />
                  </button>
                  <button
                    onClick={() => setActiveImage((prev) => (prev === uniqueImages.length - 1 ? 0 : prev + 1))}
                    className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/80 hover:bg-white rounded-full flex items-center justify-center shadow-md transition-colors"
                  >
                    <ChevronLeft className="w-6 h-6 text-navy-800" />
                  </button>
                  <div className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-navy-900/70 text-white text-sm px-3 py-1 rounded-full">
                    {activeImage + 1} / {uniqueImages.length}
                  </div>
                </>
              )}
            </div>
            {uniqueImages.length > 1 && (
              <div className="flex gap-2 mt-3 overflow-x-auto scrollbar-hide pb-2">
                {uniqueImages.map((url, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(i)}
                    className={`shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors ${
                      activeImage === i ? 'border-gold-500' : 'border-transparent'
                    }`}
                  >
                    <img src={url} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </>
        ) : (
          <div className="h-64 sm:h-80 bg-navy-100 rounded-2xl flex items-center justify-center">
            <Building2 className="w-16 h-16 text-navy-300" />
          </div>
        )}
      </div>

      {/* Main content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Title and badges */}
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-3">
              <span className={`badge ${property.listing_type === 'sale' ? 'bg-gold-500 text-navy-900' : 'bg-accent-500 text-white'}`}>
                {LISTING_TYPE_LABELS[property.listing_type]}
              </span>
              <span className="badge bg-navy-100 text-navy-700">
                {PROPERTY_TYPE_LABELS[property.property_type]}
              </span>
              {property.featured && (
                <span className="badge bg-navy-900 text-gold-400">مميز</span>
              )}
            </div>
            <h1 className="text-2xl md:text-3xl font-bold text-navy-900 mb-2">{property.title}</h1>
            <div className="flex items-center gap-1.5 text-navy-600">
              <MapPin className="w-5 h-5 text-gold-500" />
              <span>{property.governorate} - {property.city}{property.area_name ? ` - ${property.area_name}` : ''}</span>
            </div>
          </div>

          {/* Specs grid */}
          {specs.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {specs.map((spec, i) => (
                <div key={i} className="bg-navy-50 rounded-xl p-4 text-center">
                  <spec.icon className="w-6 h-6 text-gold-600 mx-auto mb-2" />
                  <div className="text-lg font-bold text-navy-900">{spec.value}</div>
                  <div className="text-xs text-navy-500">{spec.label}</div>
                </div>
              ))}
            </div>
          )}

          {/* Description */}
          {property.description && (
            <div className="bg-white border border-navy-100 rounded-2xl p-6">
              <h2 className="font-bold text-navy-900 text-lg mb-3">الوصف</h2>
              <p className="text-navy-700 leading-relaxed whitespace-pre-wrap">{property.description}</p>
            </div>
          )}

          {/* Address */}
          {property.address && (
            <div className="bg-white border border-navy-100 rounded-2xl p-6">
              <h2 className="font-bold text-navy-900 text-lg mb-3">العنوان</h2>
              <div className="flex items-start gap-2 text-navy-700">
                <MapPin className="w-5 h-5 text-gold-500 mt-0.5 shrink-0" />
                <span>{property.address}</span>
              </div>
            </div>
          )}

          {/* Property meta */}
          <div className="flex flex-wrap gap-4 text-sm text-navy-500">
            <span className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4" />
              نُشر في {new Date(property.created_at).toLocaleDateString('ar-EG')}
            </span>
            <span className="flex items-center gap-1.5">
              <Tag className="w-4 h-4" />
              {CURRENCY_SYMBOLS[property.currency]}
            </span>
          </div>

          {/* Inquiry form */}
          <div className="bg-white border border-navy-100 rounded-2xl p-6">
            <h2 className="font-bold text-navy-900 text-lg mb-2">إرسال طلب استفسار</h2>
            <p className="text-navy-500 text-sm mb-4">
              أرسل بياناتك وستقوم إدارة الموقع بالتواصل معك بخصوص هذا العقار.
            </p>

            {inquirySent ? (
              <div className="text-center py-6">
                <div className="w-14 h-14 bg-success-50 rounded-full flex items-center justify-center mx-auto mb-3">
                  <CheckCircle className="w-7 h-7 text-success-500" />
                </div>
                <h3 className="font-bold text-navy-900 mb-1">تم إرسال طلبك بنجاح</h3>
                <p className="text-navy-500 text-sm mb-4">سنتواصل معك في أقرب وقت ممكن.</p>
                <button onClick={() => setInquirySent(false)} className="btn-outline text-sm">
                  إرسال طلب آخر
                </button>
              </div>
            ) : (
              <form onSubmit={handleInquirySubmit} className="space-y-4">
                {inquiryError && (
                  <div className="flex items-center gap-2 bg-error-50 text-error-700 p-3 rounded-lg text-sm">
                    <AlertCircle className="w-5 h-5 shrink-0" />
                    {inquiryError}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-navy-700 mb-1.5">
                      الاسم <span className="text-error-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={inquiryName}
                      onChange={(e) => setInquiryName(e.target.value)}
                      required
                      placeholder="اسمك الكامل"
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-navy-700 mb-1.5">رقم الهاتف</label>
                    <input
                      type="tel"
                      value={inquiryPhone}
                      onChange={(e) => setInquiryPhone(e.target.value)}
                      placeholder="01012345678"
                      className="input-field"
                      dir="ltr"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-navy-700 mb-1.5">البريد الإلكتروني</label>
                  <input
                    type="email"
                    value={inquiryEmail}
                    onChange={(e) => setInquiryEmail(e.target.value)}
                    placeholder="example@email.com"
                    className="input-field"
                    dir="ltr"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-navy-700 mb-1.5">رسالتك</label>
                  <textarea
                    value={inquiryMessage}
                    onChange={(e) => setInquiryMessage(e.target.value)}
                    rows={3}
                    placeholder="اكتب استفسارك هنا..."
                    className="input-field resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={inquirySending}
                  className="btn-primary flex items-center justify-center gap-2 disabled:opacity-60"
                >
                  {inquirySending ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      إرسال الطلب
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Right: Contact admin card */}
        <div className="lg:col-span-1">
          <div className="sticky top-24 space-y-4">
            {/* Price card */}
            <div className="bg-white border border-navy-100 rounded-2xl p-6 shadow-sm">
              <div className="text-sm text-navy-500 mb-1">السعر</div>
              <div className="text-3xl font-bold text-gold-600 mb-1">
                {formatPrice(property.price, property.currency)}
              </div>
              {property.listing_type === 'rent' && (
                <div className="text-sm text-navy-500">شهرياً</div>
              )}

              <div className="border-t border-navy-100 mt-4 pt-4 space-y-3">
                {/* Contact admin via WhatsApp */}
                <a
                  href={adminWhatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 w-full bg-success-50 hover:bg-success-100 rounded-xl p-3 transition-colors"
                >
                  <div className="w-10 h-10 bg-success-500 rounded-xl flex items-center justify-center shrink-0">
                    <MessageCircle className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <div className="text-sm text-success-700">تواصل مع الإدارة</div>
                    <div className="font-semibold text-success-800">عبر واتساب</div>
                  </div>
                </a>

                {/* Info note */}
                <div className="flex items-start gap-2 bg-navy-50 rounded-xl p-3 text-sm text-navy-600">
                  <ShieldCheck className="w-5 h-5 text-gold-500 shrink-0 mt-0.5" />
                  <span>جميع الاستفسارات تتم عبر إدارة الموقع لضمان الجودة والموثوقية.</span>
                </div>
              </div>
            </div>

            {/* Back to search */}
            <button
              onClick={() => navigate(-1)}
              className="w-full flex items-center justify-center gap-2 py-3 text-navy-600 hover:text-gold-600 font-semibold transition-colors"
            >
              <ArrowRight className="w-5 h-5" />
              العودة للنتائج
            </button>
          </div>
        </div>
      </div>

      {/* Similar properties */}
      {similar.length > 0 && (
        <section className="mt-12">
          <h2 className="section-title mb-6">عقارات مشابهة</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {similar.map((p) => (
              <PropertyCard key={p.id} property={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
