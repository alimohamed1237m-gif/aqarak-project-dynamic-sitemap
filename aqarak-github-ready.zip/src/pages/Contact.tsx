import { useState } from 'react';
import { Phone, Mail, MapPin, Send, Loader2, CheckCircle, AlertCircle, MessageCircle, Facebook, Instagram } from 'lucide-react';
import { ADMIN_PHONE, ADMIN_WHATSAPP_NUMBER, BUSINESS_ADDRESS, FACEBOOK_URL, INSTAGRAM_URL, SUPPORT_EMAIL } from '@/lib/constants';

export default function Contact() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Simulate submission
    setTimeout(() => {
      setLoading(false);
      setSent(true);
      setName('');
      setEmail('');
      setMessage('');
    }, 1000);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-navy-900 mb-3">اتصل بنا</h1>
        <p className="text-navy-600 text-lg">نحن هنا لمساعدتك. تواصل معنا في أي وقت.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Contact info */}
        <div className="space-y-4">
          <div className="bg-white border border-navy-100 rounded-2xl p-5 flex items-center gap-4">
            <div className="w-12 h-12 bg-gold-100 rounded-xl flex items-center justify-center shrink-0">
              <Phone className="w-6 h-6 text-gold-600" />
            </div>
            <div>
              <h3 className="font-bold text-navy-900">الهاتف</h3>
              <a href={`tel:${ADMIN_PHONE}`} className="text-navy-600 text-sm hover:text-gold-600 transition-colors" dir="ltr">{ADMIN_PHONE}</a>
            </div>
          </div>

          <div className="bg-white border border-navy-100 rounded-2xl p-5 flex items-center gap-4">
            <div className="w-12 h-12 bg-gold-100 rounded-xl flex items-center justify-center shrink-0">
              <Mail className="w-6 h-6 text-gold-600" />
            </div>
            <div>
              <h3 className="font-bold text-navy-900">البريد الإلكتروني</h3>
              <a href={`mailto:${SUPPORT_EMAIL}`} className="text-navy-600 text-sm hover:text-gold-600 transition-colors" dir="ltr">{SUPPORT_EMAIL}</a>
            </div>
          </div>

          <div className="bg-white border border-navy-100 rounded-2xl p-5 flex items-center gap-4">
            <div className="w-12 h-12 bg-gold-100 rounded-xl flex items-center justify-center shrink-0">
              <MapPin className="w-6 h-6 text-gold-600" />
            </div>
            <div>
              <h3 className="font-bold text-navy-900">العنوان</h3>
              <p className="text-navy-600 text-sm">{BUSINESS_ADDRESS}</p>
            </div>
          </div>
          <div className="bg-white border border-navy-100 rounded-2xl p-5">
            <h3 className="font-bold text-navy-900 mb-3">تابعنا</h3>
            <div className="flex gap-3">
              <a
                href={FACEBOOK_URL}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="فيسبوك"
                className="flex items-center gap-2 rounded-lg bg-navy-50 px-3 py-2 text-sm font-semibold text-navy-700 hover:bg-gold-50 hover:text-gold-700 transition-colors"
              >
                <Facebook className="w-5 h-5" />
                فيسبوك
              </a>
              <a
                href={INSTAGRAM_URL}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="انستجرام"
                className="flex items-center gap-2 rounded-lg bg-navy-50 px-3 py-2 text-sm font-semibold text-navy-700 hover:bg-gold-50 hover:text-gold-700 transition-colors"
              >
                <Instagram className="w-5 h-5" />
                انستجرام
              </a>
            </div>
          </div>
        </div>

        {/* Form */}
        <div className="lg:col-span-2">
          <div className="bg-white border border-navy-100 rounded-2xl p-6 md:p-8">
            <a
              href={`https://wa.me/${ADMIN_WHATSAPP_NUMBER}?text=${encodeURIComponent('مرحباً، أود الاستفسار عن خدمات عقارك مباشر')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="mb-6 flex items-center justify-center gap-2 rounded-xl bg-success-50 px-4 py-3 font-semibold text-success-700 hover:bg-success-100 transition-colors"
            >
              <MessageCircle className="w-5 h-5" />
              تواصل مباشرة عبر واتساب
            </a>
            {sent ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-success-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-success-500" />
                </div>
                <h3 className="text-xl font-bold text-navy-900 mb-2">تم إرسال رسالتك</h3>
                <p className="text-navy-600 mb-4">سنرد عليك في أقرب وقت ممكن.</p>
                <button onClick={() => setSent(false)} className="btn-outline">
                  إرسال رسالة أخرى
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                {error && (
                  <div className="flex items-center gap-2 bg-error-50 text-error-700 p-3 rounded-lg text-sm">
                    <AlertCircle className="w-5 h-5 shrink-0" />
                    {error}
                  </div>
                )}

                <div>
                  <label className="block text-sm font-semibold text-navy-700 mb-1.5">الاسم</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    placeholder="اسمك الكامل"
                    className="input-field"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-navy-700 mb-1.5">البريد الإلكتروني</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    placeholder="example@email.com"
                    className="input-field"
                    dir="ltr"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-navy-700 mb-1.5">الرسالة</label>
                  <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    required
                    rows={5}
                    placeholder="اكتب رسالتك هنا..."
                    className="input-field resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-60"
                >
                  {loading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      إرسال
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
