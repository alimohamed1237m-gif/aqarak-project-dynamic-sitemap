import { Building2, ShieldCheck, Users, TrendingUp, Target, Eye } from 'lucide-react';

export default function About() {
  const values = [
    { icon: ShieldCheck, title: 'المصداقية', desc: 'نراجع كل عقار قبل نشره لضمان جودة المحتوى وحماية المستخدمين' },
    { icon: Users, title: 'خدمة ممتازة وموثوقة', desc: 'تتم جميع الاستفسارات عبر إدارة الموقع لضمان الجودة والموثوقية' },
    { icon: TrendingUp, title: 'التغطية الشاملة', desc: 'قاعدة بيانات ضخمة تغطي جميع المحافظات المصرية' },
    { icon: Target, title: 'سهولة الاستخدام', desc: 'منصة بسيطة وسريعة تساعدك على العثور على عقارك بسهولة' },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero */}
      <div className="text-center mb-12">
        <div className="w-16 h-16 bg-navy-900 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Building2 className="w-9 h-9 text-gold-500" />
        </div>
        <h1 className="text-3xl font-bold text-navy-900 mb-4">من نحن</h1>
        <p className="text-navy-600 text-lg max-w-2xl mx-auto leading-relaxed">
          عقارك مباشر هي منصة عقارية مصرية تربط البائع والمشتري مباشرة، دون الحاجة إلى وسطاء أو عمولات.
        </p>
      </div>

      {/* Story */}
      <div className="bg-navy-50 rounded-2xl p-6 md:p-8 mb-8">
        <h2 className="text-xl font-bold text-navy-900 mb-3">قصتنا</h2>
        <p className="text-navy-700 leading-relaxed mb-3">
          انطلقت عقارك مباشر من رؤية بسيطة: جعل عملية البحث عن العقارات في مصر أسهل وأكثر شفافية. كنا نرى
          كيف يعاني الناس من وجود وسطاء كثر بينهم وبين العقار الذي يبحثون عنه، وكيف تؤدي العمولات العالية
          إلى رفع الأسعار بشكل غير مبرر.
        </p>
        <p className="text-navy-700 leading-relaxed">
          لذلك أنشأنا هذه المنصة ليتمكن كل صاحب عقار من عرض عقاره مباشرة، وكل باحث عن عقار من التواصل
          مع المالك مباشرة عبر واتساب أو الهاتف. نراجع كل إعلان قبل نشره لضمان الجودة والمصداقية.
        </p>
      </div>

      {/* Vision & Mission */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="bg-white border border-navy-100 rounded-2xl p-6">
          <div className="w-12 h-12 bg-gold-100 rounded-xl flex items-center justify-center mb-3">
            <Eye className="w-6 h-6 text-gold-600" />
          </div>
          <h3 className="text-lg font-bold text-navy-900 mb-2">رؤيتنا</h3>
          <p className="text-navy-600 leading-relaxed">
            أن نكون المنصة العقارية الأولى في مصر من حيث الموثوقية والشفافية وسهولة الاستخدام.
          </p>
        </div>
        <div className="bg-white border border-navy-100 rounded-2xl p-6">
          <div className="w-12 h-12 bg-gold-100 rounded-xl flex items-center justify-center mb-3">
            <Target className="w-6 h-6 text-gold-600" />
          </div>
          <h3 className="text-lg font-bold text-navy-900 mb-2">رسالتنا</h3>
          <p className="text-navy-600 leading-relaxed">
            تمكين كل مصري من بيع أو شراء أو استئجار عقاره بسهولة وأمان، دون وسطاء أو عمولات.
          </p>
        </div>
      </div>

      {/* Values */}
      <h2 className="text-xl font-bold text-navy-900 mb-4">قيمنا</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {values.map((value, i) => (
          <div key={i} className="bg-white border border-navy-100 rounded-2xl p-5 flex gap-4">
            <div className="w-12 h-12 bg-navy-50 rounded-xl flex items-center justify-center shrink-0">
              <value.icon className="w-6 h-6 text-gold-600" />
            </div>
            <div>
              <h3 className="font-bold text-navy-900 mb-1">{value.title}</h3>
              <p className="text-sm text-navy-600 leading-relaxed">{value.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
