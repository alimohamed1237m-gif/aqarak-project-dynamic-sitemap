import { useEffect, useState, useCallback } from 'react';
import {
  CheckCircle, XCircle, Eye, Trash2, Star, Ban, RotateCcw,
  Loader2, Building2, Users, Clock, Search as SearchIcon, RefreshCw,
  Mail, Phone, MessageSquare, ArrowUpRight,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import type { Property, Profile, Inquiry } from '@/types';
import {
  STATUS_LABELS, formatPrice, PROPERTY_TYPE_LABELS, LISTING_TYPE_LABELS,
  INQUIRY_STATUS_LABELS,
} from '@/lib/constants';

type Tab = 'pending' | 'all' | 'users' | 'inquiries';

export default function AdminDashboard() {
  const [tab, setTab] = useState<Tab>('pending');
  const [properties, setProperties] = useState<Property[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [inquiries, setInquiries] = useState<(Inquiry & { property_title?: string })[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [stats, setStats] = useState({ total: 0, pending: 0, approved: 0, users: 0, inquiries: 0 });

  const loadProperties = useCallback(async () => {
    setLoading(true);
    let query = supabase
      .from('properties')
      .select('*, property_images(image_url, sort_order)')
      .order('created_at', { ascending: false });

    if (tab === 'pending') {
      query = query.eq('status', 'pending');
    }

    if (searchTerm) {
      query = query.or(`title.ilike.%${searchTerm}%,city.ilike.%${searchTerm}%,governorate.ilike.%${searchTerm}%`);
    }

    const { data } = await query;
    setProperties(data as Property[] || []);
    setLoading(false);
  }, [tab, searchTerm]);

  const loadUsers = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });
    setUsers(data as Profile[] || []);
    setLoading(false);
  }, []);

  const loadInquiries = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('inquiries')
      .select(`
        *,
        properties!inner(title)
      `)
      .order('created_at', { ascending: false });

    const mapped = (data || []).map((row) => ({
      ...row,
      property_title: (row as { properties?: { title?: string } }).properties?.title,
    })) as (Inquiry & { property_title?: string })[];

    setInquiries(mapped);
    setLoading(false);
  }, []);

  const loadStats = useCallback(async () => {
    const [totalRes, pendingRes, approvedRes, usersRes, inquiriesRes] = await Promise.all([
      supabase.from('properties').select('id', { count: 'exact', head: true }),
      supabase.from('properties').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
      supabase.from('properties').select('id', { count: 'exact', head: true }).eq('status', 'approved'),
      supabase.from('profiles').select('id', { count: 'exact', head: true }),
      supabase.from('inquiries').select('id', { count: 'exact', head: true }),
    ]);
    setStats({
      total: totalRes.count || 0,
      pending: pendingRes.count || 0,
      approved: approvedRes.count || 0,
      users: usersRes.count || 0,
      inquiries: inquiriesRes.count || 0,
    });
  }, []);

  useEffect(() => {
    if (tab === 'users') {
      loadUsers();
    } else if (tab === 'inquiries') {
      loadInquiries();
    } else {
      loadProperties();
    }
  }, [tab, loadProperties, loadUsers, loadInquiries]);

  useEffect(() => {
    loadStats();
  }, [loadStats]);

  const handleAction = async (action: string, propertyId: string) => {
    setActionLoading(`${action}-${propertyId}`);
    try {
      switch (action) {
        case 'approve':
          await supabase.rpc('admin_approve_property', { p_id: propertyId });
          break;
        case 'reject':
          await supabase.rpc('admin_reject_property', { p_id: propertyId });
          break;
        case 'hide':
          await supabase.rpc('admin_hide_property', { p_id: propertyId });
          break;
        case 'delete':
          if (!confirm('هل أنت متأكد من حذف هذا العقار نهائياً؟')) return;
          await supabase.rpc('admin_delete_property', { p_id: propertyId });
          break;
        case 'feature': {
          const prop = properties.find((p) => p.id === propertyId);
          await supabase.rpc('admin_set_featured', { p_id: propertyId, p_featured: !prop?.featured });
          break;
        }
      }
      await Promise.all([loadProperties(), loadStats()]);
    } catch (cause) {
      console.error('Admin action failed', cause);
    } finally {
      setActionLoading(null);
    }
  };

  const handleUserAction = async (action: string, userId: string) => {
    setActionLoading(`${action}-${userId}`);
    try {
      if (action === 'suspend') {
        await supabase.rpc('admin_suspend_user', { p_user_id: userId });
      } else if (action === 'unsuspend') {
        await supabase.rpc('admin_unsuspend_user', { p_user_id: userId });
      }
      await loadUsers();
    } catch (cause) {
      console.error('User action failed', cause);
    } finally {
      setActionLoading(null);
    }
  };

  const handleInquiryStatus = async (inquiryId: string, newStatus: string) => {
    setActionLoading(`inq-${inquiryId}`);
    try {
      await supabase.rpc('admin_update_inquiry_status', { p_id: inquiryId, p_status: newStatus });
      await Promise.all([loadInquiries(), loadStats()]);
    } catch (cause) {
      console.error('Inquiry status update failed', cause);
    } finally {
      setActionLoading(null);
    }
  };

  const handleInquiryDelete = async (inquiryId: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا الاستفسار؟')) return;
    setActionLoading(`inqdel-${inquiryId}`);
    try {
      await supabase.rpc('admin_delete_inquiry', { p_id: inquiryId });
      await Promise.all([loadInquiries(), loadStats()]);
    } catch (cause) {
      console.error('Inquiry delete failed', cause);
    } finally {
      setActionLoading(null);
    }
  };

  const statusColors: Record<string, string> = {
    pending: 'bg-warning-100 text-warning-700',
    approved: 'bg-success-100 text-success-700',
    rejected: 'bg-error-100 text-error-700',
    hidden: 'bg-navy-100 text-navy-600',
  };

  const inquiryStatusColors: Record<string, string> = {
    new: 'bg-accent-100 text-accent-700',
    contacted: 'bg-success-100 text-success-700',
    closed: 'bg-navy-100 text-navy-600',
  };

  const tabButtons: { value: Tab; label: string; icon: typeof Clock; count?: number }[] = [
    { value: 'pending', label: 'قيد المراجعة', icon: Clock, count: stats.pending },
    { value: 'all', label: 'كل العقارات', icon: Building2 },
    { value: 'inquiries', label: 'الاستفسارات', icon: MessageSquare, count: stats.inquiries },
    { value: 'users', label: 'المستخدمون', icon: Users },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-navy-900">لوحة تحكم الإدارة</h1>
        <p className="text-navy-500 text-sm mt-1">إدارة العقارات والمستخدمين والاستفسارات</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
        {[
          { label: 'إجمالي العقارات', value: stats.total, icon: Building2, color: 'bg-navy-50 text-navy-700' },
          { label: 'قيد المراجعة', value: stats.pending, icon: Clock, color: 'bg-warning-50 text-warning-700' },
          { label: 'موافق عليها', value: stats.approved, icon: CheckCircle, color: 'bg-success-50 text-success-700' },
          { label: 'الاستفسارات', value: stats.inquiries, icon: MessageSquare, color: 'bg-accent-50 text-accent-700' },
          { label: 'المستخدمون', value: stats.users, icon: Users, color: 'bg-navy-50 text-navy-700' },
        ].map((stat, i) => (
          <div key={i} className="bg-white border border-navy-100 rounded-2xl p-4">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-2 ${stat.color}`}>
              <stat.icon className="w-5 h-5" />
            </div>
            <div className="text-2xl font-bold text-navy-900">{stat.value}</div>
            <div className="text-sm text-navy-500">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-4 border-b border-navy-100 overflow-x-auto scrollbar-hide">
        {tabButtons.map((t) => (
          <button
            key={t.value}
            onClick={() => setTab(t.value)}
            className={`flex items-center gap-2 px-4 py-2.5 font-semibold text-sm border-b-2 transition-colors whitespace-nowrap ${
              tab === t.value
                ? 'border-gold-500 text-gold-600'
                : 'border-transparent text-navy-500 hover:text-navy-700'
            }`}
          >
            <t.icon className="w-4 h-4" />
            {t.label}
            {t.count != null && t.count > 0 && (
              <span className="bg-warning-500 text-white text-xs px-1.5 py-0.5 rounded-full">{t.count}</span>
            )}
          </button>
        ))}
      </div>

      {/* Search bar (properties only) */}
      {tab === 'pending' || tab === 'all' ? (
        <div className="flex items-center gap-2 mb-4">
          <div className="relative flex-1">
            <SearchIcon className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ابحث بالعنوان، المدينة، أو المحافظة..."
              className="input-field pr-11"
            />
          </div>
          <button
            onClick={() => { loadProperties(); loadStats(); }}
            className="shrink-0 w-11 h-11 flex items-center justify-center bg-navy-50 text-navy-600 rounded-lg hover:bg-navy-100 transition-colors"
          >
            <RefreshCw className="w-5 h-5" />
          </button>
        </div>
      ) : null}

      {/* Content */}
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 text-gold-500 animate-spin" />
        </div>
      ) : tab === 'users' ? (
        <div className="bg-white border border-navy-100 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-navy-50 text-navy-600">
                <tr>
                  <th className="text-right py-3 px-4 font-semibold">الاسم</th>
                  <th className="text-right py-3 px-4 font-semibold hidden sm:table-cell">البريد</th>
                  <th className="text-right py-3 px-4 font-semibold">الدور</th>
                  <th className="text-right py-3 px-4 font-semibold">الحالة</th>
                  <th className="text-right py-3 px-4 font-semibold">إجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-navy-50">
                {users.map((user) => (
                  <tr key={user.id} className="hover:bg-navy-50/50">
                    <td className="py-3 px-4 font-medium text-navy-900">{user.display_name || '—'}</td>
                    <td className="py-3 px-4 text-navy-600 hidden sm:table-cell" dir="ltr">{user.email}</td>
                    <td className="py-3 px-4">
                      <span className={`badge ${user.role === 'admin' ? 'bg-gold-100 text-gold-700' : 'bg-navy-100 text-navy-600'}`}>
                        {user.role === 'admin' ? 'مدير' : 'مستخدم'}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`badge ${user.suspended ? 'bg-error-100 text-error-700' : 'bg-success-100 text-success-700'}`}>
                        {user.suspended ? 'موقوف' : 'نشط'}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      {user.role !== 'admin' && (
                        user.suspended ? (
                          <button
                            onClick={() => handleUserAction('unsuspend', user.id)}
                            disabled={actionLoading === `unsuspend-${user.id}`}
                            className="flex items-center gap-1 text-success-600 hover:text-success-700 font-medium disabled:opacity-50"
                          >
                            {actionLoading === `unsuspend-${user.id}` ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <><RotateCcw className="w-4 h-4" /> إلغاء الإيقاف</>
                            )}
                          </button>
                        ) : (
                          <button
                            onClick={() => handleUserAction('suspend', user.id)}
                            disabled={actionLoading === `suspend-${user.id}`}
                            className="flex items-center gap-1 text-error-600 hover:text-error-700 font-medium disabled:opacity-50"
                          >
                            {actionLoading === `suspend-${user.id}` ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <><Ban className="w-4 h-4" /> إيقاف</>
                            )}
                          </button>
                        )
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : tab === 'inquiries' ? (
        inquiries.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-20 h-20 bg-navy-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="w-10 h-10 text-navy-300" />
            </div>
            <h3 className="text-xl font-bold text-navy-800 mb-2">لا توجد استفسارات</h3>
            <p className="text-navy-500">ستظهر هنا استفسارات العملاء عن العقارات</p>
          </div>
        ) : (
          <div className="space-y-3">
            {inquiries.map((inq) => (
              <div key={inq.id} className="bg-white border border-navy-100 rounded-2xl p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  {/* Buyer info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`badge ${inquiryStatusColors[inq.status]}`}>
                        {INQUIRY_STATUS_LABELS[inq.status]}
                      </span>
                      <span className="text-xs text-navy-400">
                        {new Date(inq.created_at).toLocaleDateString('ar-EG')}
                      </span>
                    </div>
                    <h3 className="font-bold text-navy-900 mb-1">{inq.name}</h3>
                    <div className="flex flex-wrap gap-3 text-sm text-navy-600 mb-2">
                      {inq.phone && (
                        <span className="flex items-center gap-1" dir="ltr">
                          <Phone className="w-4 h-4 text-gold-500" />
                          {inq.phone}
                        </span>
                      )}
                      {inq.email && (
                        <span className="flex items-center gap-1" dir="ltr">
                          <Mail className="w-4 h-4 text-gold-500" />
                          {inq.email}
                        </span>
                      )}
                    </div>
                    {inq.message && (
                      <p className="text-sm text-navy-600 bg-navy-50 rounded-lg p-3 mt-2">{inq.message}</p>
                    )}
                    <Link
                      to={`/property/${inq.property_id}`}
                      className="inline-flex items-center gap-1 text-sm text-gold-600 hover:text-gold-700 font-medium mt-2"
                    >
                      العقار: {inq.property_title || 'عرض العقار'}
                      <ArrowUpRight className="w-4 h-4" />
                    </Link>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col gap-2 shrink-0">
                    <select
                      value={inq.status}
                      onChange={(e) => handleInquiryStatus(inq.id, e.target.value)}
                      disabled={actionLoading === `inq-${inq.id}`}
                      className="input-field text-sm py-2 px-3"
                    >
                      <option value="new">جديد</option>
                      <option value="contacted">تم التواصل</option>
                      <option value="closed">مغلق</option>
                    </select>
                    <button
                      onClick={() => handleInquiryDelete(inq.id)}
                      disabled={actionLoading === `inqdel-${inq.id}`}
                      className="flex items-center justify-center gap-1 text-error-600 hover:text-error-700 text-sm font-medium py-2 px-3 rounded-lg bg-error-50 hover:bg-error-100 transition-colors disabled:opacity-50"
                    >
                      {actionLoading === `inqdel-${inq.id}` ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <><Trash2 className="w-4 h-4" /> حذف</>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )
      ) : properties.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-20 h-20 bg-navy-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <Building2 className="w-10 h-10 text-navy-300" />
          </div>
          <h3 className="text-xl font-bold text-navy-800 mb-2">
            {tab === 'pending' ? 'لا توجد عقارات قيد المراجعة' : 'لا توجد عقارات'}
          </h3>
        </div>
      ) : (
        <div className="space-y-3">
          {properties.map((property) => {
            const imageUrl = property.main_image_url || property.property_images?.[0]?.image_url;
            return (
              <div key={property.id} className="bg-white border border-navy-100 rounded-2xl p-4">
                <div className="flex gap-4 items-start">
                  <div className="shrink-0">
                    {imageUrl ? (
                      <img src={imageUrl} alt={property.title} className="w-20 h-20 rounded-xl object-cover" />
                    ) : (
                      <div className="w-20 h-20 bg-navy-50 rounded-xl flex items-center justify-center">
                        <Building2 className="w-8 h-8 text-navy-300" />
                      </div>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`badge ${statusColors[property.status]}`}>
                        {STATUS_LABELS[property.status]}
                      </span>
                      {property.featured && (
                        <span className="badge bg-gold-100 text-gold-700">
                          <Star className="w-3 h-3" /> مميز
                        </span>
                      )}
                    </div>
                    <h3 className="font-bold text-navy-900 truncate">{property.title}</h3>
                    <p className="text-sm text-navy-500 truncate">
                      {property.governorate} - {property.city} • {PROPERTY_TYPE_LABELS[property.property_type]} • {LISTING_TYPE_LABELS[property.listing_type]}
                    </p>
                    <p className="text-gold-600 font-bold mt-1">{formatPrice(property.price, property.currency)}</p>

                    {/* Owner contact details - admin only */}
                    {(property.contact_phone || property.contact_whatsapp) && (
                      <div className="flex flex-wrap gap-3 mt-2 text-sm">
                        {property.contact_phone && (
                          <span className="flex items-center gap-1 text-navy-700" dir="ltr">
                            <Phone className="w-4 h-4 text-gold-500" />
                            {property.contact_phone}
                          </span>
                        )}
                        {property.contact_whatsapp && (
                          <span className="flex items-center gap-1 text-navy-700" dir="ltr">
                            <MessageSquare className="w-4 h-4 text-success-500" />
                            {property.contact_whatsapp}
                          </span>
                        )}
                      </div>
                    )}
                  </div>

                  <div className="flex flex-wrap gap-2 shrink-0 justify-end">
                    {property.status === 'pending' && (
                      <>
                        <button
                          onClick={() => handleAction('approve', property.id)}
                          disabled={actionLoading === `approve-${property.id}`}
                          className="w-9 h-9 flex items-center justify-center bg-success-50 text-success-600 rounded-lg hover:bg-success-100 transition-colors disabled:opacity-50"
                          title="موافقة"
                        >
                          {actionLoading === `approve-${property.id}` ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-5 h-5" />}
                        </button>
                        <button
                          onClick={() => handleAction('reject', property.id)}
                          disabled={actionLoading === `reject-${property.id}`}
                          className="w-9 h-9 flex items-center justify-center bg-error-50 text-error-600 rounded-lg hover:bg-error-100 transition-colors disabled:opacity-50"
                          title="رفض"
                        >
                          {actionLoading === `reject-${property.id}` ? <Loader2 className="w-4 h-4 animate-spin" /> : <XCircle className="w-5 h-5" />}
                        </button>
                      </>
                    )}
                    {property.status === 'approved' && (
                      <button
                        onClick={() => handleAction('hide', property.id)}
                        disabled={actionLoading === `hide-${property.id}`}
                        className="w-9 h-9 flex items-center justify-center bg-navy-50 text-navy-600 rounded-lg hover:bg-navy-100 transition-colors disabled:opacity-50"
                        title="إخفاء"
                      >
                        {actionLoading === `hide-${property.id}` ? <Loader2 className="w-4 h-4 animate-spin" /> : <Eye className="w-5 h-5" />}
                      </button>
                    )}
                    <button
                      onClick={() => handleAction('feature', property.id)}
                      disabled={actionLoading === `feature-${property.id}`}
                      className={`w-9 h-9 flex items-center justify-center rounded-lg transition-colors disabled:opacity-50 ${
                        property.featured
                          ? 'bg-gold-500 text-navy-900 hover:bg-gold-600'
                          : 'bg-gold-50 text-gold-600 hover:bg-gold-100'
                      }`}
                      title={property.featured ? 'إزالة التمييز' : 'تمييز'}
                    >
                      {actionLoading === `feature-${property.id}` ? <Loader2 className="w-4 h-4 animate-spin" /> : <Star className="w-5 h-5" />}
                    </button>
                    <button
                      onClick={() => handleAction('delete', property.id)}
                      disabled={actionLoading === `delete-${property.id}`}
                      className="w-9 h-9 flex items-center justify-center bg-error-50 text-error-600 rounded-lg hover:bg-error-100 transition-colors disabled:opacity-50"
                      title="حذف"
                    >
                      {actionLoading === `delete-${property.id}` ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-5 h-5" />}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
