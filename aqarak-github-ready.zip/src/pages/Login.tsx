import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Building2, Mail, Lock, AlertCircle, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { SUPPORT_EMAIL } from '@/lib/constants';

export default function Login() {
  const navigate = useNavigate();
  const { refreshProfile } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (signInError) throw signInError;

      await refreshProfile();
      const { data: signedInProfile } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', signInData.user.id)
        .maybeSingle();

      navigate(signedInProfile?.role === 'admin' || email.trim().toLowerCase() === SUPPORT_EMAIL ? '/admin' : '/');
    } catch (cause) {
      console.error('Login failed', cause);
      setError('البريد الإلكتروني أو كلمة المرور غير صحيحة. حاول مرة أخرى.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-200px)] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-navy-900 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Building2 className="w-9 h-9 text-gold-500" />
          </div>
          <h1 className="text-2xl font-bold text-navy-900">تسجيل الدخول</h1>
          <p className="text-navy-500 mt-1">أدخل بياناتك للوصول إلى حسابك</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="bg-white border border-navy-100 rounded-2xl p-6 md:p-8 shadow-sm space-y-5">
          {error && (
            <div className="flex items-center gap-2 bg-error-50 text-error-700 p-3 rounded-lg text-sm">
              <AlertCircle className="w-5 h-5 shrink-0" />
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-semibold text-navy-700 mb-1.5">البريد الإلكتروني</label>
            <div className="relative">
              <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                placeholder="example@email.com"
                className="input-field pr-11"
                dir="ltr"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-navy-700 mb-1.5">كلمة المرور</label>
            <div className="relative">
              <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                placeholder="••••••••"
                className="input-field pr-11"
                dir="ltr"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn-primary w-full flex items-center justify-center gap-2 disabled:opacity-60"
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              'تسجيل الدخول'
            )}
          </button>
        </form>

        {/* Register link */}
        <p className="text-center mt-6 text-navy-600">
          ليس لديك حساب؟{' '}
          <Link to="/register" className="text-gold-600 font-semibold hover:text-gold-700">
            أنشئ حساب جديد
          </Link>
        </p>


      </div>
    </div>
  );
}
