import { FileText } from 'lucide-react';

export default function Terms() {
  const sections = [
    {
      title: 'قبول الشروط',
      content: 'باستخدامك لمنصة عقارك مباشر، فإنك توافق على هذه الشروط والأحكام. إذا كنت لا توافق عليها، يرجى عدم استخدام المنصة.',
    },
    {
      title: 'استخدام المنصة',
      content: 'تسمح المنصة للمستخدمين المسجلين بنشر عقاراتهم للبيع أو الإيجار. يجب أن تكون البيانات المقدمة صحيحة ودقيقة. يُمنع نشر إعلانات مضللة أو وهمية.',
    },
    {
      title: 'مراجعة العقارات',
      content: 'تخضع جميع العقارات المنشورة لمراجعة من فريق الإدارة قبل نشرها. نحتفظ بالحق في الموافقة أو الرفض أو حذف أي عقار دون ذكر الأسباب.',
    },
    {
      title: 'مسؤولية المستخدم',
      content: 'أنت مسؤول عن صحة البيانات التي تقدمها وعن التواصل مع المهتمين بعقاراتك. عقارك مباشر لا تتدخل في عمليات البيع أو الإيجار بين الأطراف.',
    },
    {
      title: 'محتوى المستخدمين',
      content: 'أنت تتحمل المسؤولية الكاملة عن المحتوى الذي تنشره. يجب ألا يحتوي المحتوى على مواد مخالفة للقانون أو مسيئة أو تنتهك حقوق الآخرين.',
    },
    {
      title: 'إيقاف الحساب',
      content: 'نحتفظ بالحق في إيقاف أو حذف أي حساب يخالف هذه الشروط أو يستخدم المنصة بشكل غير لائق. يمكن للمستخدمين حذف حساباتهم في أي وقت.',
    },
    {
      title: 'حدود المسؤولية',
      content: 'منصة عقارك مباشر توفر خدمة وساطة مجانية بين البائعين والمشترين. لا نتحمل مسؤولية أي صفقات أو نزاعات بين المستخدمين.',
    },
    {
      title: 'تعديل الشروط',
      content: 'نحتفظ بالحق في تعديل هذه الشروط في أي وقت. سيتم نشر التعديلات على هذه الصفحة، واستمرارك في استخدام المنصة يعني موافقتك على الشروط المعدلة.',
    },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-10">
        <div className="w-16 h-16 bg-navy-900 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <FileText className="w-9 h-9 text-gold-500" />
        </div>
        <h1 className="text-3xl font-bold text-navy-900 mb-3">شروط الاستخدام</h1>
        <p className="text-navy-500 text-sm">آخر تحديث: يناير 2026</p>
      </div>

      <div className="bg-navy-50 rounded-2xl p-4 md:p-6 mb-6">
        <p className="text-navy-700 leading-relaxed">
          يرجى قراءة هذه الشروط بعناية قبل استخدام منصة عقارك مباشر. استخدامك للمنصة يعني موافقتك على
          جميع الشروط والأحكام الموضحة أدناه.
        </p>
      </div>

      <div className="space-y-6">
        {sections.map((section, i) => (
          <div key={i} className="bg-white border border-navy-100 rounded-2xl p-6">
            <h2 className="text-lg font-bold text-navy-900 mb-2">
              {i + 1}. {section.title}
            </h2>
            <p className="text-navy-700 leading-relaxed">{section.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
