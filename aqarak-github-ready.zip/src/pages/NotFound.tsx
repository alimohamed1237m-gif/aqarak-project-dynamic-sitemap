import { Link } from 'react-router-dom';
import { Home as HomeIcon, Search } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-[calc(100vh-300px)] flex items-center justify-center px-4 py-12">
      <div className="text-center">
        <div className="text-8xl font-bold text-gold-500 mb-4">٤٠٤</div>
        <h1 className="text-2xl font-bold text-navy-900 mb-3">الصفحة غير موجودة</h1>
        <p className="text-navy-500 mb-8 max-w-md mx-auto">
          عذراً، الصفحة التي تبحث عنها غير متاحة أو تم نقلها إلى مكان آخر.
        </p>
        <div className="flex gap-3 justify-center">
          <Link to="/" className="btn-primary flex items-center gap-2">
            <HomeIcon className="w-5 h-5" />
            الصفحة الرئيسية
          </Link>
          <Link to="/search" className="btn-outline flex items-center gap-2">
            <Search className="w-5 h-5" />
            البحث عن عقار
          </Link>
        </div>
      </div>
    </div>
  );
}
