import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Search, Building2, Home as HomeIcon, Store, Map as MapIcon, Briefcase, Building,
  TrendingUp, ShieldCheck, Users, ArrowLeft,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Property } from '@/types';
import {
  GOVERNORATES, PROPERTY_TYPES, LISTING_TYPES,
} from '@/lib/constants';
import PropertyCard from '@/components/PropertyCard';

const ICON_MAP: Record<string, typeof Building2> = {
  Building2, Home: HomeIcon, Store, Map: MapIcon, Briefcase, Building,
};

export default function Home() {
  const navigate = useNavigate();
  const [featured, setFeatured] = useState<Property[]>([]);
  const [recent, setRecent] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchForm, setSearchForm] = useState({
    governorate: '',
    property_type: '',
    listing_type: '',
  });

  useEffect(() => {
    async function loadData() {
      const [featuredRes, recentRes] = await Promise.all([
        supabase
          .from('properties')
          .select('*, property_images(image_url, sort_order)')
          .eq('status', 'approved')
          .eq('featured', true)
          .order('created_at', { ascending: false })
          .limit(6),
        supabase
          .from('properties')
          .select('*, property_images(image_url, sort_order)')
          .eq('status', 'approved')
          .order('created_at', { ascending: false })
          .limit(8),
      ]);
      setFeatured(featuredRes.data as Property[] || []);
      setRecent(recentRes.data as Property[] || []);
      setLoading(false);
    }
    loadData();
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (searchForm.governorate) params.set('governorate', searchForm.governorate);
    if (searchForm.property_type) params.set('type', searchForm.property_type);
    if (searchForm.listing_type) params.set('listing', searchForm.listing_type);
    navigate(`/search?${params.toString()}`);
  };

  return (
    <div>
      {/* Hero section */}
      <section className="relative bg-navy-900 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <img
            src="https://images.pexels.com/photos/302769/pexels-photo-302769.jpeg"
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-navy-900/80 to-navy-900" />

        <div className="relative max-w-8xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <div className="text-center mb-10">
            <h1 className="text-3xl md:text-5xl font-bold text-white mb-4 text-balance">
              ابحث عن عقارك في مصر <span className="text-gold-500">مباشرة</span>
            </h1>
            <p className="text-navy-200 text-lg md:text-xl max-w-2xl mx-auto">
              آلاف العقارات للبيع والإيجار في جميع المحافظات المصرية - خدمة ممتازة وموثوقة
            </p>
          </div>

          {/* Search bar */}
          <form
            onSubmit={handleSearch}
            className="bg-white rounded-2xl p-4 md:p-6 shadow-2xl max-w-5xl mx-auto"
          >
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div>
                <label className="block text-sm font-semibold text-navy-700 mb-1.5">المحافظة</label>
                <select
                  value={searchForm.governorate}
                  onChange={(e) => setSearchForm({ ...searchForm, governorate: e.target.value })}
                  className="input-field"
                >
                  <option value="">كل المحافظات</option>
                  {GOVERNORATES.map((g) => (
                    <option key={g} value={g}>{g}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-navy-700 mb-1.5">نوع العقار</label>
                <select
                  value={searchForm.property_type}
                  onChange={(e) => setSearchForm({ ...searchForm, property_type: e.target.value })}
                  className="input-field"
                >
                  <option value="">كل الأنواع</option>
                  {PROPERTY_TYPES.map((t) => (
                    <option key={t.value} value={t.value}>{t.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-navy-700 mb-1.5">العملية</label>
                <select
                  value={searchForm.listing_type}
                  onChange={(e) => setSearchForm({ ...searchForm, listing_type: e.target.value })}
                  className="input-field"
                >
                  <option value="">الكل</option>
                  {LISTING_TYPES.map((t) => (
                    <option key={t.value} value={t.value}>{t.label}</option>
                  ))}
                </select>
              </div>
              <div className="flex items-end">
                <button type="submit" className="btn-primary w-full flex items-center justify-center gap-2">
                  <Search className="w-5 h-5" />
                  بحث
                </button>
              </div>
            </div>
          </form>
        </div>
      </section>

      {/* Property categories */}
      <section className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <h2 className="section-title">تصفح حسب النوع</h2>
          <p className="section-subtitle">اختر نوع العقار الذي تبحث عنه</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {PROPERTY_TYPES.map((type) => {
            const Icon = ICON_MAP[type.icon] || Building2;
            return (
              <Link
                key={type.value}
                to={`/search?type=${type.value}`}
                className="group flex flex-col items-center gap-3 p-6 bg-navy-50 rounded-2xl hover:bg-white hover:shadow-lg transition-all duration-300 border border-transparent hover:border-gold-200"
              >
                <div className="w-14 h-14 bg-white group-hover:bg-gold-500 rounded-2xl flex items-center justify-center transition-colors duration-300 shadow-sm">
                  <Icon className="w-7 h-7 text-navy-800 group-hover:text-navy-900 transition-colors" />
                </div>
                <span className="font-semibold text-navy-800 group-hover:text-gold-600 transition-colors">
                  {type.label}
                </span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Featured listings */}
      <section className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="section-title">عقارات مميزة</h2>
            <p className="section-subtitle">أبرز العقارات المتاحة الآن</p>
          </div>
          <Link to="/search?featured=true" className="flex items-center gap-1 text-gold-600 font-semibold hover:text-gold-700 transition-colors text-sm">
            عرض الكل
            <ArrowLeft className="w-4 h-4" />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="card">
                <div className="h-52 skeleton" />
                <div className="p-4 space-y-3">
                  <div className="h-5 skeleton rounded" />
                  <div className="h-4 w-2/3 skeleton rounded" />
                  <div className="h-8 skeleton rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {featured.map((p) => (
              <PropertyCard key={p.id} property={p} />
            ))}
          </div>
        )}
      </section>

      {/* Why us section */}
      <section className="bg-navy-50 py-16 mt-8">
        <div className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="section-title">لماذا عقارك مباشر؟</h2>
            <p className="section-subtitle">منصة موثوقة تربطك بالعقار الذي تبحث عنه</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: ShieldCheck, title: 'موثوق وآمن', desc: 'كل العقارات تمر بمراجعة من فريقنا لضمان الجودة والمصداقية' },
              { icon: Users, title: 'تواصل مع الإدارة', desc: 'تتم جميع الاستفسارات عبر إدارة الموقع لضمان الجودة والمصداقية' },
              { icon: TrendingUp, title: 'آلاف العقارات', desc: 'قاعدة بيانات ضخمة تغطي جميع المحافظات المصرية' },
            ].map((feature, i) => (
              <div key={i} className="bg-white rounded-2xl p-8 text-center shadow-sm hover:shadow-lg transition-shadow">
                <div className="w-16 h-16 bg-gold-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="w-8 h-8 text-gold-600" />
                </div>
                <h3 className="text-xl font-bold text-navy-900 mb-2">{feature.title}</h3>
                <p className="text-navy-500 leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Recent listings */}
      <section className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="section-title">أحدث العقارات</h2>
            <p className="section-subtitle">أضيف حديثاً على المنصة</p>
          </div>
          <Link to="/search" className="flex items-center gap-1 text-gold-600 font-semibold hover:text-gold-700 transition-colors text-sm">
            عرض الكل
            <ArrowLeft className="w-4 h-4" />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="card">
                <div className="h-52 skeleton" />
                <div className="p-4 space-y-3">
                  <div className="h-5 skeleton rounded" />
                  <div className="h-4 w-2/3 skeleton rounded" />
                  <div className="h-8 skeleton rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {recent.map((p) => (
              <PropertyCard key={p.id} property={p} />
            ))}
          </div>
        )}
      </section>

      {/* CTA section */}
      <section className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-gradient-to-l from-navy-900 to-navy-800 rounded-3xl p-8 md:p-12 text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-64 h-64 bg-gold-500/10 rounded-full -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 right-0 w-64 h-64 bg-gold-500/10 rounded-full translate-x-1/2 translate-y-1/2" />
          <div className="relative">
            <h2 className="text-2xl md:text-4xl font-bold text-white mb-4">
              لديك عقار للبيع أو للإيجار؟
            </h2>
            <p className="text-navy-200 text-lg mb-6 max-w-2xl mx-auto">
              أضف عقارك الآن وصل إلى آلاف العملاء - مجاناً مع خدمة ممتازة وموثوقة
            </p>
            <Link to="/submit" className="btn-primary inline-flex items-center gap-2 text-lg">
              <Building2 className="w-5 h-5" />
              أضف عقارك مجاناً
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
