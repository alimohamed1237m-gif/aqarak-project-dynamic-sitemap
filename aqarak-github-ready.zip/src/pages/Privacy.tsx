import { Shield } from 'lucide-react';

export default function Privacy() {
  const sections = [
    {
      title: 'جمع البيانات',
      content: 'نقوم بجمع البيانات التي تقدمها عند إنشاء حساب أو إضافة عقار، مثل الاسم، البريد الإلكتروني، رقم الهاتف، وبيانات العقار. لا نقوم بجمع بيانات حساسة غير ضرورية.',
    },
    {
      title: 'استخدام البيانات',
      content: 'نستخدم بياناتك لتمكينك من استخدام المنصة، مثل نشر عقاراتك، التواصل مع المهتمين بها، وتحسين خدماتنا. لا نقوم ببيع بياناتك لأطراف ثالثة.',
    },
    {
      title: 'حماية البيانات',
      content: 'نتخذ إجراءات أمنية مناسبة لحماية بياناتك من الوصول غير المصرح به، بما في ذلك التشفير وضوابط الوصول. يتم تخزين البيانات على خوادم آمنة.',
    },
    {
      title: 'مشاركة البيانات',
      content: 'قد نشارك بياناتك مع الجهات المختصة عند الضرورة القانونية. بيانات التواصل الخاصة بك تظهر للعملاء المهتمين بعقاراتك لتمكين التواصل المباشر.',
    },
    {
      title: 'حقوقك',
      content: 'لك الحق في الوصول إلى بياناتك وتعديلها أو حذفها في أي وقت. يمكنك حذف حسابك وجميع بياناتك المرتبطة به من خلال التواصل معنا.',
    },
    {
      title: 'ملفات تعريف الارتباط (Cookies)',
      content: 'نستخدم ملفات تعريف الارتباط لتحسين تجربتك على المنصة. يمكنك تعطيلها من إعدادات المتصفح، لكن ذلك قد يؤثر على بعض الميزات.',
    },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center mb-10">
        <div className="w-16 h-16 bg-navy-900 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Shield className="w-9 h-9 text-gold-500" />
        </div>
        <h1 className="text-3xl font-bold text-navy-900 mb-3">سياسة الخصوصية</h1>
        <p className="text-navy-500 text-sm">آخر تحديث: يناير 2026</p>
      </div>

      <div className="bg-navy-50 rounded-2xl p-4 md:p-6 mb-6">
        <p className="text-navy-700 leading-relaxed">
          تشرح سياسة الخصوصية هذه كيفية جمع عقارك مباشر لبياناتك واستخدامها وحمايتها. باستخدامك للمنصة،
          فإنك توافق على الممارسات الموضحة في هذه السياسة.
        </p>
      </div>

      <div className="space-y-6">
        {sections.map((section, i) => (
          <div key={i} className="bg-white border border-navy-100 rounded-2xl p-6">
            <h2 className="text-lg font-bold text-navy-900 mb-2">
              {i + 1}. {section.title}
            </h2>
            <p className="text-navy-700 leading-relaxed">{section.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
