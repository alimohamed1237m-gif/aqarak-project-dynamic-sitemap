import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { MessageCircle } from 'lucide-react';
import { AuthProvider } from '@/context/AuthContext';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { ProtectedRoute, AdminRoute } from '@/components/ProtectedRoute';

import Home from '@/pages/Home';
import Search from '@/pages/Search';
import PropertyDetails from '@/pages/PropertyDetails';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import SubmitProperty from '@/pages/SubmitProperty';
import MyListings from '@/pages/MyListings';
import AdminDashboard from '@/pages/AdminDashboard';
import About from '@/pages/About';
import Contact from '@/pages/Contact';
import Privacy from '@/pages/Privacy';
import Terms from '@/pages/Terms';
import NotFound from '@/pages/NotFound';
import { ADMIN_WHATSAPP_NUMBER } from '@/lib/constants';

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <div className="min-h-screen flex flex-col bg-white">
          <Navbar />
          <main className="flex-1">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/search" element={<Search />} />
              <Route path="/property/:id" element={<PropertyDetails />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route
                path="/submit"
                element={
                  <ProtectedRoute>
                    <SubmitProperty />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/my-listings"
                element={
                  <ProtectedRoute>
                    <MyListings />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin"
                element={
                  <AdminRoute>
                    <AdminDashboard />
                  </AdminRoute>
                }
              />
              <Route path="/about" element={<About />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/privacy" element={<Privacy />} />
              <Route path="/terms" element={<Terms />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          <Footer />
          <a
            href={`https://wa.me/${ADMIN_WHATSAPP_NUMBER}?text=${encodeURIComponent('مرحباً، أود الاستفسار عن خدمات عقارك مباشر')}`}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="تواصل مع عقارك مباشر عبر واتساب"
            className="fixed bottom-5 right-5 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-success-500 text-white shadow-lg shadow-success-500/30 transition-all hover:scale-110 hover:bg-success-600 focus:outline-none focus:ring-4 focus:ring-success-500/30"
          >
            <MessageCircle className="h-7 w-7" />
          </a>
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
