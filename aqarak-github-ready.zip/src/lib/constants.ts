import type { PropertyType, ListingType, Currency } from '@/types';

export const PROPERTY_TYPES: { value: PropertyType; label: string; icon: string }[] = [
  { value: 'apartment', label: 'شقق', icon: 'Building2' },
  { value: 'villa', label: 'فيلات', icon: 'Home' },
  { value: 'shop', label: 'محلات', icon: 'Store' },
  { value: 'land', label: 'أراضي', icon: 'Map' },
  { value: 'office', label: 'مكاتب', icon: 'Briefcase' },
  { value: 'commercial', label: 'عمارات تجارية', icon: 'Building' },
];

export const LISTING_TYPES: { value: ListingType; label: string }[] = [
  { value: 'sale', label: 'للبيع' },
  { value: 'rent', label: 'للإيجار' },
];

export const CURRENCIES: { value: Currency; label: string; symbol: string }[] = [
  { value: 'EGP', label: 'جنيه مصري', symbol: 'ج.م' },
  { value: 'USD', label: 'دولار أمريكي', symbol: '$' },
  { value: 'SAR', label: 'ريال سعودي', symbol: 'ر.س' },
];

export const GOVERNORATES: string[] = [
  'القاهرة',
  'الجيزة',
  'الإسكندرية',
  'الدقهلية',
  'البحر الأحمر',
  'البحيرة',
  'الفيوم',
  'الغربية',
  'الإسماعيلية',
  'المنوفية',
  'المنيا',
  'الوادي الجديد',
  'السويس',
  'أسوان',
  'أسيوط',
  'بني سويف',
  'بورسعيد',
  'دمياط',
  'الشرقية',
  'جنوب سيناء',
  'كفر الشيخ',
  'مطروح',
  'الأقصر',
  'قنا',
  'شمال سيناء',
  'سوهاج',
];

export const PROPERTY_TYPE_LABELS: Record<PropertyType, string> = {
  apartment: 'شقة',
  villa: 'فيلا',
  shop: 'محل',
  land: 'أرض',
  office: 'مكتب',
  commercial: 'عمارة تجارية',
};

export const LISTING_TYPE_LABELS: Record<ListingType, string> = {
  sale: 'للبيع',
  rent: 'للإيجار',
};

export const STATUS_LABELS: Record<string, string> = {
  pending: 'قيد المراجعة',
  approved: 'موافق عليه',
  rejected: 'مرفوض',
  hidden: 'مخفي',
};

export const CURRENCY_SYMBOLS: Record<Currency, string> = {
  EGP: 'ج.م',
  USD: '$',
  SAR: 'ر.س',
};

export function formatPrice(price: number, currency: Currency): string {
  const symbol = CURRENCY_SYMBOLS[currency];
  const formatted = new Intl.NumberFormat('ar-EG', { maximumFractionDigits: 0 }).format(price);
  return `${formatted} ${symbol}`;
}

export const ADMIN_PHONE = '+201015742055';
export const ADMIN_WHATSAPP_NUMBER = '201015742055';
export const SUPPORT_EMAIL = 'aqarakmobasher@gmail.com';
export const BUSINESS_ADDRESS = 'دمياط، مصر';
export const FACEBOOK_URL = 'https://www.facebook.com/share/19bhYyBdks/';
export const INSTAGRAM_URL = 'https://www.instagram.com/aqarakmobasher?vrfl=MXV3a3BqMGtkbjNjdQ==';

export const INQUIRY_STATUS_LABELS: Record<string, string> = {
  new: 'جديد',
  contacted: 'تم التواصل',
  closed: 'مغلق',
};
