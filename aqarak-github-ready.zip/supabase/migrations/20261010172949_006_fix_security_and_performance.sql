/*
# Fix security and performance issues

1. Security Fixes
- Add SET search_path = public to update_updated_at() to prevent search_path manipulation.
- Revoke EXECUTE on handle_new_user() from anon and PUBLIC (it is a trigger, not an API endpoint).

2. Performance Fixes
- Replace auth.uid() with (select auth.uid()) in all RLS policies so the value is computed
  once per query instead of once per row, which significantly speeds up table scans.
*/

-- ============================================================
-- Fix update_updated_at search_path
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- ============================================================
-- Lock down handle_new_user (trigger only, not a public RPC)
-- ============================================================
REVOKE EXECUTE ON FUNCTION handle_new_user() FROM PUBLIC, anon;

-- ============================================================
-- profiles: replace auth.uid() with (select auth.uid())
-- ============================================================
DROP POLICY IF EXISTS "profiles_select_own" ON profiles;
CREATE POLICY "profiles_select_own"
ON profiles FOR SELECT
TO authenticated
USING ((select auth.uid()) = id);

DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own"
ON profiles FOR UPDATE
TO authenticated
USING ((select auth.uid()) = id)
WITH CHECK ((select auth.uid()) = id);

DROP POLICY IF EXISTS "profiles_select_admin" ON profiles;
CREATE POLICY "profiles_select_admin"
ON profiles FOR SELECT
TO authenticated
USING (is_admin());

-- ============================================================
-- properties: replace auth.uid() with (select auth.uid())
-- ============================================================
DROP POLICY IF EXISTS "properties_select_public" ON properties;
CREATE POLICY "properties_select_public"
ON properties FOR SELECT
TO anon, authenticated
USING (
  status = 'approved'
  OR user_id = (select auth.uid())
  OR EXISTS (SELECT 1 FROM profiles WHERE profiles.id = (select auth.uid()) AND profiles.role = 'admin')
);

DROP POLICY IF EXISTS "properties_insert_own" ON properties;
CREATE POLICY "properties_insert_own"
ON properties FOR INSERT
TO authenticated
WITH CHECK (
  user_id = (select auth.uid())
  AND NOT EXISTS (SELECT 1 FROM profiles WHERE profiles.id = (select auth.uid()) AND profiles.suspended = true)
);

DROP POLICY IF EXISTS "properties_update_own" ON properties;
CREATE POLICY "properties_update_own"
ON properties FOR UPDATE
TO authenticated
USING (user_id = (select auth.uid()) AND status IN ('pending', 'rejected'))
WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "properties_delete_own" ON properties;
CREATE POLICY "properties_delete_own"
ON properties FOR DELETE
TO authenticated
USING (user_id = (select auth.uid()));

-- ============================================================
-- property_images: replace auth.uid() with (select auth.uid())
-- ============================================================
DROP POLICY IF EXISTS "property_images_select" ON property_images;
CREATE POLICY "property_images_select"
ON property_images FOR SELECT
TO anon, authenticated
USING (
  EXISTS (
    SELECT 1 FROM properties
    WHERE properties.id = property_images.property_id
    AND (
      properties.status = 'approved'
      OR properties.user_id = (select auth.uid())
      OR EXISTS (SELECT 1 FROM profiles WHERE profiles.id = (select auth.uid()) AND profiles.role = 'admin')
    )
  )
);

DROP POLICY IF EXISTS "property_images_insert" ON property_images;
CREATE POLICY "property_images_insert"
ON property_images FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM properties
    WHERE properties.id = property_images.property_id
    AND properties.user_id = (select auth.uid())
    AND properties.status IN ('pending', 'rejected')
  )
);

DROP POLICY IF EXISTS "property_images_delete" ON property_images;
CREATE POLICY "property_images_delete"
ON property_images FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM properties
    WHERE properties.id = property_images.property_id
    AND properties.user_id = (select auth.uid())
  )
);

-- ============================================================
-- inquiries: already uses is_admin(), no auth.uid() changes needed
-- but lock handle_new_user tighter
-- ============================================================
