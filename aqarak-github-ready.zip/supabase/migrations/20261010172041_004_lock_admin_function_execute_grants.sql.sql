/*
# Restrict administrative database functions to signed-in users

1. Purpose
- Remove anonymous EXECUTE privileges from all administrative and authorization helper functions.

2. Security Changes
- Anonymous visitors cannot invoke administrator operations or the `is_admin()` helper directly.
- Authenticated users may still invoke the functions, but each function continues to enforce the active administrator check internally.
- No tables, columns, or user data are deleted or changed by this migration.

3. Important Notes
- Row-level security remains the final data access control.
- The browser's admin screen is only a convenience; database functions independently verify the caller's role.
*/

REVOKE EXECUTE ON FUNCTION is_admin() FROM anon;
GRANT EXECUTE ON FUNCTION is_admin() TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_approve_property(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION admin_approve_property(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_reject_property(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION admin_reject_property(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_hide_property(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION admin_hide_property(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_delete_property(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION admin_delete_property(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_set_featured(uuid, boolean) FROM anon;
GRANT EXECUTE ON FUNCTION admin_set_featured(uuid, boolean) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_suspend_user(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION admin_suspend_user(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_unsuspend_user(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION admin_unsuspend_user(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_set_role(uuid, text) FROM anon;
GRANT EXECUTE ON FUNCTION admin_set_role(uuid, text) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_update_property(uuid, text, text, numeric, text, text, text, text, text, text, text, numeric, integer, integer, text, text) FROM anon;
GRANT EXECUTE ON FUNCTION admin_update_property(uuid, text, text, numeric, text, text, text, text, text, text, text, numeric, integer, integer, text, text) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_update_inquiry_status(uuid, text) FROM anon;
GRANT EXECUTE ON FUNCTION admin_update_inquiry_status(uuid, text) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_delete_inquiry(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION admin_delete_inquiry(uuid) TO authenticated;
