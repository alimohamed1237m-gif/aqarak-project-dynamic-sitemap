/*
# Create inquiries table for buyer lead capture

## Purpose
All buyer inquiries route through the platform admin instead of contacting property owners directly.
Buyers submit an inquiry form on the property details page; inquiries are saved to the database
and visible only to admins in the Admin Dashboard.

## New Table
- inquiries: id, property_id (FK->properties), name, phone, email, message, status (new/contacted/closed), created_at

## Security
- RLS enabled. INSERT: public (anon+authenticated). SELECT/UPDATE/DELETE: admin only via is_admin().
*/

CREATE TABLE IF NOT EXISTS inquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id uuid NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  name text NOT NULL,
  phone text,
  email text,
  message text,
  status text NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'closed')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE inquiries ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_inquiries_property_id ON inquiries(property_id);
CREATE INDEX IF NOT EXISTS idx_inquiries_status ON inquiries(status);
CREATE INDEX IF NOT EXISTS idx_inquiries_created_at ON inquiries(created_at DESC);

DROP POLICY IF EXISTS "inquiries_insert_public" ON inquiries;
CREATE POLICY "inquiries_insert_public"
ON inquiries FOR INSERT
TO anon, authenticated
WITH CHECK (true);

DROP POLICY IF EXISTS "inquiries_select_admin" ON inquiries;
CREATE POLICY "inquiries_select_admin"
ON inquiries FOR SELECT
TO authenticated
USING (is_admin());

DROP POLICY IF EXISTS "inquiries_update_admin" ON inquiries;
CREATE POLICY "inquiries_update_admin"
ON inquiries FOR UPDATE
TO authenticated
USING (is_admin())
WITH CHECK (is_admin());

DROP POLICY IF EXISTS "inquiries_delete_admin" ON inquiries;
CREATE POLICY "inquiries_delete_admin"
ON inquiries FOR DELETE
TO authenticated
USING (is_admin());

CREATE OR REPLACE FUNCTION admin_update_inquiry_status(p_id uuid, p_status text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'غير مصرح';
  END IF;
  IF p_status NOT IN ('new', 'contacted', 'closed') THEN
    RAISE EXCEPTION 'حالة غير صالحة';
  END IF;
  UPDATE inquiries SET status = p_status WHERE id = p_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION admin_update_inquiry_status(uuid, text) FROM anon;
GRANT EXECUTE ON FUNCTION admin_update_inquiry_status(uuid, text) TO authenticated;

CREATE OR REPLACE FUNCTION admin_delete_inquiry(p_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'غير مصرح';
  END IF;
  DELETE FROM inquiries WHERE id = p_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION admin_delete_inquiry(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION admin_delete_inquiry(uuid) TO authenticated;