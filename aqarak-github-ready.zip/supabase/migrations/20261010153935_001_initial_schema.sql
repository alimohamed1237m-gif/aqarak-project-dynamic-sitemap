/*
# Aqarak Mobasher - Initial Schema

Creates the core database tables for a real estate marketplace for Egypt.

## Tables

1. **profiles** — Extends auth.users with role (user/admin), phone, display_name, suspended status.
2. **properties** — Real estate listings with type, price, location, status (pending/approved/rejected/hidden).
3. **property_images** — Gallery images for each property.

## Security

- RLS enabled on all tables.
- Column-level UPDATE grants on profiles (display_name, phone, whatsapp only) and properties (content columns only; status, featured, user_id NOT writable).
- Admin operations via SECURITY DEFINER functions that check is_admin() internally.
- Auto-creates profile on signup via trigger.
*/

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ============================================================
-- PROFILES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  display_name text,
  phone text,
  whatsapp text,
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  suspended boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles_select_own" ON profiles;
CREATE POLICY "profiles_select_own"
ON profiles FOR SELECT
TO authenticated
USING (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own"
ON profiles FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

REVOKE UPDATE ON profiles FROM authenticated;
GRANT UPDATE (display_name, phone, whatsapp) ON profiles TO authenticated;

-- ============================================================
-- PROPERTIES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS properties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  price numeric NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'EGP' CHECK (currency IN ('EGP', 'USD', 'SAR')),
  property_type text NOT NULL CHECK (property_type IN ('apartment', 'villa', 'shop', 'land', 'office', 'commercial')),
  listing_type text NOT NULL CHECK (listing_type IN ('sale', 'rent')),
  governorate text NOT NULL,
  city text NOT NULL,
  area_name text,
  address text,
  area_sqm numeric,
  bedrooms int,
  bathrooms int,
  contact_phone text,
  contact_whatsapp text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'hidden')),
  featured boolean NOT NULL DEFAULT false,
  main_image_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE properties ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_properties_status ON properties(status);
CREATE INDEX IF NOT EXISTS idx_properties_type ON properties(property_type);
CREATE INDEX IF NOT EXISTS idx_properties_listing_type ON properties(listing_type);
CREATE INDEX IF NOT EXISTS idx_properties_governorate ON properties(governorate);
CREATE INDEX IF NOT EXISTS idx_properties_city ON properties(city);
CREATE INDEX IF NOT EXISTS idx_properties_user_id ON properties(user_id);
CREATE INDEX IF NOT EXISTS idx_properties_featured ON properties(featured) WHERE featured = true;

DROP POLICY IF EXISTS "properties_select_public" ON properties;
CREATE POLICY "properties_select_public"
ON properties FOR SELECT
TO anon, authenticated
USING (
  status = 'approved'
  OR user_id = auth.uid()
  OR EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
);

DROP POLICY IF EXISTS "properties_insert_own" ON properties;
CREATE POLICY "properties_insert_own"
ON properties FOR INSERT
TO authenticated
WITH CHECK (
  user_id = auth.uid()
  AND NOT EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.suspended = true)
);

DROP POLICY IF EXISTS "properties_update_own" ON properties;
CREATE POLICY "properties_update_own"
ON properties FOR UPDATE
TO authenticated
USING (user_id = auth.uid() AND status IN ('pending', 'rejected'))
WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "properties_delete_own" ON properties;
CREATE POLICY "properties_delete_own"
ON properties FOR DELETE
TO authenticated
USING (user_id = auth.uid());

REVOKE UPDATE ON properties FROM authenticated;
GRANT UPDATE (
  title, description, price, currency, property_type, listing_type,
  governorate, city, area_name, address, area_sqm, bedrooms, bathrooms,
  contact_phone, contact_whatsapp, main_image_url, updated_at
) ON properties TO authenticated;

-- ============================================================
-- PROPERTY_IMAGES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS property_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id uuid NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
  image_url text NOT NULL,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE property_images ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_property_images_property_id ON property_images(property_id);

DROP POLICY IF EXISTS "property_images_select" ON property_images;
CREATE POLICY "property_images_select"
ON property_images FOR SELECT
TO anon, authenticated
USING (
  EXISTS (
    SELECT 1 FROM properties
    WHERE properties.id = property_images.property_id
    AND (
      properties.status = 'approved'
      OR properties.user_id = auth.uid()
      OR EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.role = 'admin')
    )
  )
);

DROP POLICY IF EXISTS "property_images_insert" ON property_images;
CREATE POLICY "property_images_insert"
ON property_images FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM properties
    WHERE properties.id = property_images.property_id
    AND properties.user_id = auth.uid()
    AND properties.status IN ('pending', 'rejected')
  )
);

DROP POLICY IF EXISTS "property_images_delete" ON property_images;
CREATE POLICY "property_images_delete"
ON property_images FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM properties
    WHERE properties.id = property_images.property_id
    AND properties.user_id = auth.uid()
  )
);

-- ============================================================
-- ADMIN HELPER FUNCTION: is_admin()
-- ============================================================
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
    AND profiles.suspended = false
  );
$$;

-- ============================================================
-- ADMIN FUNCTIONS (SECURITY DEFINER)
-- ============================================================

CREATE OR REPLACE FUNCTION admin_approve_property(p_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'غير مصرح';
  END IF;
  UPDATE properties SET status = 'approved', updated_at = now() WHERE id = p_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION admin_approve_property(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION admin_approve_property(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION admin_reject_property(p_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'غير مصرح';
  END IF;
  UPDATE properties SET status = 'rejected', updated_at = now() WHERE id = p_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION admin_reject_property(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION admin_reject_property(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION admin_hide_property(p_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'غير مصرح';
  END IF;
  UPDATE properties SET status = 'hidden', updated_at = now() WHERE id = p_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION admin_hide_property(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION admin_hide_property(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION admin_delete_property(p_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'غير مصرح';
  END IF;
  DELETE FROM properties WHERE id = p_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION admin_delete_property(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION admin_delete_property(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION admin_set_featured(p_id uuid, p_featured boolean)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'غير مصرح';
  END IF;
  UPDATE properties SET featured = p_featured, updated_at = now() WHERE id = p_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION admin_set_featured(uuid, boolean) FROM anon;
GRANT EXECUTE ON FUNCTION admin_set_featured(uuid, boolean) TO authenticated;

CREATE OR REPLACE FUNCTION admin_suspend_user(p_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'غير مصرح';
  END IF;
  UPDATE profiles SET suspended = true, updated_at = now() WHERE id = p_user_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION admin_suspend_user(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION admin_suspend_user(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION admin_unsuspend_user(p_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'غير مصرح';
  END IF;
  UPDATE profiles SET suspended = false, updated_at = now() WHERE id = p_user_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION admin_unsuspend_user(uuid) FROM anon;
GRANT EXECUTE ON FUNCTION admin_unsuspend_user(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION admin_set_role(p_user_id uuid, p_role text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'غير مصرح';
  END IF;
  IF p_role NOT IN ('user', 'admin') THEN
    RAISE EXCEPTION 'دور غير صالح';
  END IF;
  UPDATE profiles SET role = p_role, updated_at = now() WHERE id = p_user_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION admin_set_role(uuid, text) FROM anon;
GRANT EXECUTE ON FUNCTION admin_set_role(uuid, text) TO authenticated;

CREATE OR REPLACE FUNCTION admin_update_property(
  p_id uuid,
  p_title text,
  p_description text,
  p_price numeric,
  p_currency text,
  p_property_type text,
  p_listing_type text,
  p_governorate text,
  p_city text,
  p_area_name text,
  p_address text,
  p_area_sqm numeric,
  p_bedrooms int,
  p_bathrooms int,
  p_contact_phone text,
  p_contact_whatsapp text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'غير مصرح';
  END IF;
  UPDATE properties SET
    title = p_title,
    description = p_description,
    price = p_price,
    currency = p_currency,
    property_type = p_property_type,
    listing_type = p_listing_type,
    governorate = p_governorate,
    city = p_city,
    area_name = p_area_name,
    address = p_address,
    area_sqm = p_area_sqm,
    bedrooms = p_bedrooms,
    bathrooms = p_bathrooms,
    contact_phone = p_contact_phone,
    contact_whatsapp = p_contact_whatsapp,
    updated_at = now()
  WHERE id = p_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION admin_update_property(uuid, text, text, numeric, text, text, text, text, text, text, text, numeric, int, int, text, text) FROM anon;
GRANT EXECUTE ON FUNCTION admin_update_property(uuid, text, text, numeric, text, text, text, text, text, text, text, numeric, int, int, text, text) TO authenticated;

-- ============================================================
-- TRIGGER: Auto-create profile on signup
-- ============================================================
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO profiles (id, email, display_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)));
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ============================================================
-- UPDATED_AT triggers
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS properties_updated_at ON properties;
CREATE TRIGGER properties_updated_at
  BEFORE UPDATE ON properties
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS profiles_updated_at ON profiles;
CREATE TRIGGER profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();