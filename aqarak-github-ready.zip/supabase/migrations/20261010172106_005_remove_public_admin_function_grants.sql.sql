/*
# Remove public execution from administrative functions

1. Purpose
- Close inherited PUBLIC EXECUTE privileges that can keep SECURITY DEFINER functions reachable by anonymous callers.

2. Security Changes
- Administrative RPC functions and the `is_admin()` helper are explicitly revoked from PUBLIC and anon.
- Authenticated callers retain EXECUTE access, while every administrative function still checks `is_admin()` internally.
- No tables or user data are modified.

3. Important Notes
- This complements row-level security and the existing authenticated-only policies.
- The browser cannot grant itself administrator access; the database remains authoritative.
*/

REVOKE EXECUTE ON FUNCTION is_admin() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION is_admin() TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_approve_property(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION admin_approve_property(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_reject_property(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION admin_reject_property(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_hide_property(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION admin_hide_property(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_delete_property(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION admin_delete_property(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_set_featured(uuid, boolean) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION admin_set_featured(uuid, boolean) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_suspend_user(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION admin_suspend_user(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_unsuspend_user(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION admin_unsuspend_user(uuid) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_set_role(uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION admin_set_role(uuid, text) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_update_property(uuid, text, text, numeric, text, text, text, text, text, text, text, numeric, integer, integer, text, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION admin_update_property(uuid, text, text, numeric, text, text, text, text, text, text, text, numeric, integer, integer, text, text) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_update_inquiry_status(uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION admin_update_inquiry_status(uuid, text) TO authenticated;

REVOKE EXECUTE ON FUNCTION admin_delete_inquiry(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION admin_delete_inquiry(uuid) TO authenticated;
