/*
# Promote the official account to Super Administrator

1. Purpose
- Automatically grant the official Aqarak Mobasher account full administrator privileges.
- Keep authorization enforced by the database rather than relying on browser-only checks.

2. Modified Tables
- `profiles.role`: existing role value is set to `admin` for the official email.
- `profiles`: existing admin-only row visibility is expanded so administrators can review owner accounts and contact details.

3. Authentication Behavior
- New signups using `aqarakmobasher@gmail.com` automatically receive `role = 'admin'` through the existing auth-user profile trigger.
- Existing profiles with this email are promoted idempotently.
- Password authentication remains Supabase email/password authentication; this migration does not create or expose a password.

4. Security
- The role assignment is performed inside the SECURITY DEFINER profile-creation trigger, not by client-provided metadata.
- The profile role remains protected from client updates by existing column-level privileges.
- Administrators can read profiles, including owner phone and WhatsApp fields, only when `is_admin()` confirms the authenticated account is an active administrator.
- No anonymous access is added to private profile data.

5. Important Notes
- If the official account does not exist yet, it can use the existing registration screen with this email and its chosen password; the trigger will promote it automatically.
- If the account already exists, its profile is promoted immediately by this migration.
*/

UPDATE profiles
SET role = 'admin', updated_at = now()
WHERE lower(email) = lower('aqarakmobasher@gmail.com');

DROP POLICY IF EXISTS "profiles_select_admin" ON profiles;
CREATE POLICY "profiles_select_admin"
ON profiles FOR SELECT
TO authenticated
USING (is_admin());

CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO profiles (id, email, display_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)),
    CASE
      WHEN lower(NEW.email) = lower('aqarakmobasher@gmail.com') THEN 'admin'
      ELSE 'user'
    END
  );
  RETURN NEW;
END;
$$;
