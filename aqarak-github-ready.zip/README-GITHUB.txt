GitHub-ready source package for Aqarak Mobasher.

Upload/extract these files at the ROOT of your GitHub repository.
Do not commit your real .env file. Configure VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY as environment variables in your hosting provider (e.g. Netlify).

Build command: npm run build
Publish directory: dist
