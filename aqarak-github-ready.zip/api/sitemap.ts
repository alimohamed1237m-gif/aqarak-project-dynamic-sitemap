import { createClient } from '@supabase/supabase-js';

const SITE_URL = 'https://aqarakmobasher.com';

const staticRoutes = [
  { path: '/', changefreq: 'daily', priority: '1.0' },
  { path: '/search', changefreq: 'daily', priority: '0.9' },
  { path: '/about', changefreq: 'monthly', priority: '0.5' },
  { path: '/contact', changefreq: 'monthly', priority: '0.5' },
  { path: '/privacy', changefreq: 'yearly', priority: '0.3' },
  { path: '/terms', changefreq: 'yearly', priority: '0.3' },
];

type SitemapProperty = { id: string; updated_at: string | null; created_at: string | null };
type SitemapRequest = { method?: string };
type SitemapResponse = {
  setHeader: (name: string, value: string) => void;
  status: (code: number) => SitemapResponse;
  send: (body: string) => void;
};

function xmlEscape(value: string): string {
  return value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
}

export default async function handler(req: SitemapRequest, res: SitemapResponse) {
  if (req.method && req.method !== 'GET' && req.method !== 'HEAD') {
    res.setHeader('Allow', 'GET, HEAD');
    return res.status(405).send('Method Not Allowed');
  }

  res.setHeader('Content-Type', 'application/xml; charset=utf-8');
  res.setHeader('Cache-Control', 'public, s-maxage=300, stale-while-revalidate=600');

  const entries = staticRoutes.map((route) => ({
    loc: `${SITE_URL}${route.path}`,
    changefreq: route.changefreq,
    priority: route.priority,
    lastmod: undefined as string | undefined,
  }));

  const supabaseUrl = process.env.VITE_SUPABASE_URL;
  const supabaseAnonKey = process.env.VITE_SUPABASE_ANON_KEY;

  if (supabaseUrl && supabaseAnonKey) {
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { data, error } = await supabase
      .from('properties')
      .select('id, updated_at, created_at')
      .eq('status', 'approved')
      .order('updated_at', { ascending: false })
      .limit(50000);

    if (error) {
      console.error('Sitemap property query failed:', error.message);
    } else {
      for (const property of (data ?? []) as SitemapProperty[]) {
        entries.push({
          loc: `${SITE_URL}/property/${encodeURIComponent(property.id)}`,
          changefreq: 'weekly',
          priority: '0.8',
          lastmod: property.updated_at ?? property.created_at ?? undefined,
        });
      }
    }
  } else {
    console.error('Missing VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY environment variables for dynamic sitemap.');
  }

  const urls = entries.map((entry) => {
    const lastmod = entry.lastmod ? `<lastmod>${xmlEscape(entry.lastmod)}</lastmod>` : '';
    return `<url><loc>${xmlEscape(entry.loc)}</loc>${lastmod}<changefreq>${entry.changefreq}</changefreq><priority>${entry.priority}</priority></url>`;
  }).join('');

  return res.status(200).send(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls}</urlset>`);
}
